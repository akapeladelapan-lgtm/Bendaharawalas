export type PaymentStatus = 'LUNAS' | 'ANGSURAN PERTAMA';

export interface PaymentTariffs {
  angsuranPertama: number; // 1700000
  lunas: number;           // 3350000
}

export interface StudentPayment {
  id: string;
  name: string;
  classGrade: string;
  status: PaymentStatus;
  amount?: number;
  notes?: string;
}

export interface MessageConfig {
  headerGreeting: string;
  activityTitle: string;
  schoolName: string;
  updateDate: string;
  treasurerName: string;
  treasurerContact?: string;
  closingInstruction: string;
  closingSalutation: string;
  showAmount: boolean;
  numberingStyle: 'numeric' | 'bullet';
  selectedClassFilter: string; // 'all' or specific class e.g. '7A'
  showEmptyCategories: boolean;
  includeTariffSchemeInMessage: boolean;
  paymentTariffs: PaymentTariffs;
}

export interface ClassGroupSummary {
  classGrade: string;
  lunas: StudentPayment[];
  angsuranPertama: StudentPayment[];
  totalStudents: number;
  totalAmountLunas: number;
  totalAmountAngsuranPertama: number;
  totalAmount: number;
}
