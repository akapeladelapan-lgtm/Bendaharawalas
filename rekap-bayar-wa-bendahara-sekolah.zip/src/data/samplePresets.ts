export interface SamplePreset {
  id: string;
  title: string;
  description: string;
  rawText: string;
}

export const SAMPLE_PRESETS: SamplePreset[] = [
  {
    id: 'skema-resmi-sekolah',
    title: '🎓 Rekap Skema Sekolah (2 Status)',
    description: 'Angsuran 1 (1.7jt) dan Lunas (3.35jt)',
    rawText: `Ahmad Fauzi	7A	Lunas	3.350.000
Budi Santoso	7A	Angsuran Pertama	1.700.000
Citra Kirana	7A	Lunas	3.350.000
Dimas Anggara	7A	Angsuran Pertama	1.700.000
Eka Prasetya	7B	Lunas	3.350.000
Fajar Nugraha	7B	Angsuran Pertama	1.700.000
Gita Gutawa	7B	Lunas	3.350.000
Hendra Wijaya	7B	Angsuran Pertama	1.700.000
Intan Permata	8A	Lunas	3.350.000
Joko Susilo	8A	Angsuran Pertama	1.700.000
Kiki Amalia	8A	Lunas	3.350.000`,
  },
  {
    id: 'wa-chat-informal',
    title: '💬 Catatan Singkat Chat WA Bendahara',
    description: 'Nama dan status harian',
    rawText: `1. Muhammad Rizky - 7A - lunas 3.350.000
2. Putri Rahayu, 7A, angsuran 1 (trf bca)
3. Rangga Putra - 7B - angsuran pertama 1.700.000
4. Salsa Bila - 7B - lunas
5. Tiara Andini, 8A, angsuran pertama
6. Umar Bakri - 8A - angsuran 1
7. Vina Panduwinata, 8B, lunas
8. Wahyu Hidayat - 8B - angsuran pertama`,
  },
  {
    id: 'multi-grade-detailed',
    title: '🏫 Data Siswa Kelas 7, 8, 9 Campuran',
    description: 'Format copy paste Excel/Sheets multi kelas',
    rawText: `Aditya Pratama	7A	Lunas	3350000
Annisa Zahra	7A	Angsuran Pertama	1700000
Bagas Kara	7A	Lunas	3350000
Cantika Dewi	7B	Lunas	3350000
Dedi Corbuzier	7B	Angsuran Pertama	1700000
Erina Gudono	8A	Lunas	3350000
Farhan Akhtar	8A	Angsuran Pertama	1700000
Ghani Alamsyah	8B	Lunas	3350000
Hani Syakira	9A	Angsuran Pertama	1700000`,
  },
];
