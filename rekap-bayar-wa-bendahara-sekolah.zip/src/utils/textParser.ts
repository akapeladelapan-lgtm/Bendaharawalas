import { StudentPayment, PaymentStatus, PaymentTariffs } from '../types/payment';
import { parseNominal } from './numberFormat';

export const DEFAULT_TARIFFS: PaymentTariffs = {
  angsuranPertama: 1700000,
  lunas: 3350000,
};

export function normalizeStatus(raw: string): PaymentStatus {
  const s = raw.toLowerCase().trim();

  // Any mention of angsuran, cicilan, dp, termin, etc. maps to ANGSURAN PERTAMA
  if (
    s.includes('angsur') ||
    s.includes('cicil') ||
    s.includes('ccl') ||
    s.includes('dp') ||
    s.includes('pertama') ||
    s.includes('tahap') ||
    s.includes('awal') ||
    s.includes('separuh') ||
    s.includes('sebagian') ||
    s.includes('belum lunas')
  ) {
    return 'ANGSURAN PERTAMA';
  }

  return 'LUNAS';
}

export function getDefaultTariffForStatus(status: PaymentStatus, tariffs: PaymentTariffs = DEFAULT_TARIFFS): number {
  switch (status) {
    case 'ANGSURAN PERTAMA':
      return tariffs.angsuranPertama;
    case 'LUNAS':
      return tariffs.lunas;
  }
}

export function normalizeClass(raw: string): string {
  let c = raw.trim();
  if (!c) return 'Lainnya';
  c = c.replace(/^(?:kelas|kls|class)\s+/i, '');
  return c.toUpperCase();
}

/**
 * Intelligent deterministic local parser for any pasted raw text.
 */
export function parseRawPaymentText(
  text: string,
  tariffs: PaymentTariffs = DEFAULT_TARIFFS
): StudentPayment[] {
  if (!text || !text.trim()) return [];

  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const results: StudentPayment[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    const lower = line.toLowerCase();
    if (
      (lower.includes('nama') && lower.includes('kelas')) ||
      (lower.includes('siswa') && lower.includes('status')) ||
      lower === 'rekap pembayaran' ||
      lower.startsWith('---')
    ) {
      continue;
    }

    const cleanedLine = line.replace(/^[\d]+[\.\)]\s*|^[-*•]\s*/, '').trim();

    let parts: string[] = [];
    if (cleanedLine.includes('\t')) {
      parts = cleanedLine.split('\t').map((p) => p.trim());
    } else if (cleanedLine.includes('|')) {
      parts = cleanedLine.split('|').map((p) => p.trim());
    } else if (cleanedLine.includes(';') && cleanedLine.split(';').length >= 3) {
      parts = cleanedLine.split(';').map((p) => p.trim());
    } else if (cleanedLine.includes(',') && cleanedLine.split(',').length >= 3) {
      parts = cleanedLine.split(',').map((p) => p.trim());
    } else if (cleanedLine.includes(' - ') || cleanedLine.includes(' – ')) {
      parts = cleanedLine.split(/\s*[-–]\s*/).map((p) => p.trim());
    }

    if (parts.length >= 2) {
      const name = parts[0];
      let classGrade = '7A';
      let status: PaymentStatus = 'LUNAS';
      let amount = 0;
      let notes = '';

      if (parts.length === 2) {
        const second = parts[1];
        if (
          second.toLowerCase().includes('lunas') ||
          second.toLowerCase().includes('angsur') ||
          second.toLowerCase().includes('cicil')
        ) {
          status = normalizeStatus(second);
        } else {
          classGrade = normalizeClass(second);
        }
      } else if (parts.length === 3) {
        classGrade = normalizeClass(parts[1]);
        status = normalizeStatus(parts[2]);
        amount = parseNominal(parts[2]);
      } else if (parts.length >= 4) {
        classGrade = normalizeClass(parts[1]);
        status = normalizeStatus(parts[2]);
        amount = parseNominal(parts[3]);
        if (parts.length > 4) {
          notes = parts.slice(4).join(' ');
        }
      }

      if (name && name.length >= 2) {
        if (!amount || amount === 0) {
          amount = getDefaultTariffForStatus(status, tariffs);
        }

        results.push({
          id: `stu_${Date.now()}_${Math.random().toString(36).substring(2, 7)}_${i}`,
          name: name.replace(/^["']|["']$/g, ''),
          classGrade: classGrade || '7A',
          status,
          amount: amount || undefined,
          notes: notes || undefined,
        });
        continue;
      }
    }

    // Fallback: regex search
    const classMatch = cleanedLine.match(
      /\b(?:kelas\s+)?([0-9]{1,2}\s*[-–/]?\s*[A-Za-z0-9]+|(?:X|XI|XII|VII|VIII|IX)\s*[-–/]?\s*[A-Za-z0-9\s]+)\b/i
    );
    let nominal = parseNominal(cleanedLine);
    const status: PaymentStatus = normalizeStatus(cleanedLine);

    let extractedClass = '7A';
    let remainingText = cleanedLine;

    if (classMatch && classMatch[1]) {
      extractedClass = normalizeClass(classMatch[1]);
      remainingText = remainingText.replace(classMatch[0], ' ');
    }

    remainingText = remainingText
      .replace(
        /(?:lunas|angsuran\s*pertama|angsuran\s*1|cicilan\s*pertama|cicilan\s*1|ccl\s*1|dp|bayar\s*full|sudah\s*transfer|transfer|angsuran|cicilan)/gi,
        ''
      )
      .replace(/rp\.?\s*[\d.,]+/gi, '')
      .replace(/[\d.,]+\s*(?:jt|juta|rb|ribu|k)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();

    if (!nominal || nominal === 0) {
      nominal = getDefaultTariffForStatus(status, tariffs);
    }

    if (remainingText.length >= 2) {
      results.push({
        id: `stu_${Date.now()}_${Math.random().toString(36).substring(2, 7)}_${i}`,
        name: remainingText,
        classGrade: extractedClass,
        status,
        amount: nominal > 0 ? nominal : undefined,
      });
    }
  }

  return results;
}
