import { PaymentStatus, PaymentTariffs, StudentPayment } from '../types/payment';
import { normalizeClass, getDefaultTariffForStatus } from './textParser';

export interface ParsedCsvStudent {
  name: string;
  classGrade: string;
  status?: PaymentStatus;
  amount?: number;
  notes?: string;
}

/**
 * Parses raw CSV / tabular text of (Nama, Kelas) or (Nama, Kelas, Status, Nominal)
 */
export function parseCsvStudents(
  text: string,
  defaultStatus: PaymentStatus = 'ANGSURAN PERTAMA',
  tariffs: PaymentTariffs
): StudentPayment[] {
  if (!text || !text.trim()) return [];

  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const students: StudentPayment[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];

    // Skip potential header lines
    const lower = line.toLowerCase();
    if (
      (lower.includes('nama') && lower.includes('kelas')) ||
      (lower.includes('name') && lower.includes('class')) ||
      lower.startsWith('---')
    ) {
      continue;
    }

    // Determine delimiter: comma, semicolon, tab, or pipe
    let parts: string[] = [];
    if (line.includes('\t')) {
      parts = line.split('\t').map((p) => p.trim());
    } else if (line.includes(';')) {
      parts = line.split(';').map((p) => p.trim());
    } else if (line.includes('|')) {
      parts = line.split('|').map((p) => p.trim());
    } else if (line.includes(',')) {
      // Basic CSV split respecting quotes
      parts = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/).map((p) =>
        p.trim().replace(/^["']|["']$/g, '')
      );
    } else if (line.includes(' - ')) {
      parts = line.split(/\s*[-–]\s*/).map((p) => p.trim());
    } else {
      // Space separation fallback: e.g. "Ahmad Fauzi 7A"
      const match = line.match(/^(.*?)\s+([0-9]{1,2}[A-Za-z0-9]*|[A-Za-z]+[0-9]+)$/);
      if (match) {
        parts = [match[1].trim(), match[2].trim()];
      } else {
        parts = [line.trim(), '7A'];
      }
    }

    if (parts.length >= 1 && parts[0].length > 0) {
      const name = parts[0];
      const classGrade = normalizeClass(parts[1] || '7A');

      let status = defaultStatus;
      let amount = getDefaultTariffForStatus(status, tariffs);

      // If CSV has 3rd or 4th columns specifying status/amount
      if (parts.length >= 3 && parts[2]) {
        const rawStatus = parts[2].toLowerCase();
        if (rawStatus.includes('lunas')) status = 'LUNAS';
        else status = 'ANGSURAN PERTAMA';
        amount = getDefaultTariffForStatus(status, tariffs);
      }

      students.push({
        id: `stu_csv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}_${i}`,
        name,
        classGrade: classGrade || '7A',
        status,
        amount,
      });
    }
  }

  return students;
}
