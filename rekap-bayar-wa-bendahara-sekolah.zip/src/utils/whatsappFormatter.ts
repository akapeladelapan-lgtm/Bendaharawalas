import { StudentPayment, MessageConfig, ClassGroupSummary } from '../types/payment';
import { formatRupiah } from './numberFormat';
import { DEFAULT_TARIFFS } from './textParser';

export function compareClassGrades(a: string, b: string): number {
  return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
}

export function groupStudentsByClass(students: StudentPayment[]): ClassGroupSummary[] {
  const map = new Map<string, StudentPayment[]>();

  for (const s of students) {
    const cls = s.classGrade.trim() || 'Lainnya';
    if (!map.has(cls)) {
      map.set(cls, []);
    }
    map.get(cls)!.push(s);
  }

  const sortedClasses = Array.from(map.keys()).sort(compareClassGrades);

  return sortedClasses.map((cls) => {
    const list = map.get(cls)!;
    const sortedStudents = [...list].sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
    );

    const lunas = sortedStudents.filter((s) => s.status === 'LUNAS');
    const angsuranPertama = sortedStudents.filter((s) => s.status === 'ANGSURAN PERTAMA');

    const totalAmountLunas = lunas.reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const totalAmountAngsuranPertama = angsuranPertama.reduce(
      (acc, curr) => acc + (curr.amount || 0),
      0
    );

    return {
      classGrade: cls,
      lunas,
      angsuranPertama,
      totalStudents: list.length,
      totalAmountLunas,
      totalAmountAngsuranPertama,
      totalAmount: totalAmountLunas + totalAmountAngsuranPertama,
    };
  });
}

export function generateWhatsAppMessage(
  students: StudentPayment[],
  config: MessageConfig,
  targetClass?: string
): string {
  if (students.length === 0) {
    return 'Belum ada data pembayaran siswa yang dimasukkan.';
  }

  const allGroups = groupStudentsByClass(students);
  const groups =
    targetClass && targetClass !== 'all'
      ? allGroups.filter((g) => g.classGrade.toLowerCase() === targetClass.toLowerCase())
      : allGroups;

  if (groups.length === 0) {
    return `Tidak ada data untuk kelas ${targetClass}.`;
  }

  const lines: string[] = [];

  // 1. Salam Pembuka yang Sopan
  lines.push(config.headerGreeting.trim());
  lines.push('');

  if (config.activityTitle) {
    lines.push(`*${config.activityTitle.toUpperCase()}*`);
  }
  if (config.schoolName) {
    lines.push(`*${config.schoolName}*`);
  }
  if (config.updateDate) {
    lines.push(`Per Tanggal: ${config.updateDate}`);
  }

  // 2. Rincian Skema Biaya Pembayaran jika diaktifkan (Hanya Angsuran 1 dan Lunas)
  if (config.includeTariffSchemeInMessage && config.paymentTariffs) {
    lines.push('');
    lines.push('*Status & Skema Pembayaran:*');
    lines.push(`1. Angsuran Pertama: ${formatRupiah(config.paymentTariffs.angsuranPertama)}`);
    lines.push(`2. Lunas: ${formatRupiah(config.paymentTariffs.lunas)}`);
  }

  lines.push('────────────────────────');
  lines.push('');

  // 3. Daftar Per Kelas (Hanya 2 Status: ✅ LUNAS dan ⏳ ANGSURAN PERTAMA)
  groups.forEach((group, groupIdx) => {
    const classDisplay = group.classGrade.toUpperCase().startsWith('KELAS')
      ? group.classGrade.toUpperCase()
      : `KELAS ${group.classGrade.toUpperCase()}`;
    lines.push(`*${classDisplay}*`);

    // Kategori 1: ✅ LUNAS (Rp 3.350.000)
    lines.push('*✅ LUNAS*');
    if (group.lunas.length > 0) {
      group.lunas.forEach((s, idx) => {
        const prefix = config.numberingStyle === 'bullet' ? '• ' : `${idx + 1}. `;
        let line = `${prefix}${s.name}`;
        if (config.showAmount && s.amount !== undefined && s.amount > 0) {
          line += ` (${formatRupiah(s.amount)})`;
        }
        if (s.notes) {
          line += ` - _${s.notes}_`;
        }
        lines.push(line);
      });
    } else {
      lines.push('-(Belum ada)-');
    }
    lines.push('');

    // Kategori 2: ⏳ ANGSURAN PERTAMA (Rp 1.700.000)
    lines.push('*⏳ ANGSURAN PERTAMA*');
    if (group.angsuranPertama.length > 0) {
      group.angsuranPertama.forEach((s, idx) => {
        const prefix = config.numberingStyle === 'bullet' ? '• ' : `${idx + 1}. `;
        let line = `${prefix}${s.name}`;
        if (config.showAmount && s.amount !== undefined && s.amount > 0) {
          line += ` (${formatRupiah(s.amount)})`;
        }
        if (s.notes) {
          line += ` - _${s.notes}_`;
        }
        lines.push(line);
      });
    } else {
      lines.push('-(Belum ada)-');
    }

    if (groupIdx < groups.length - 1) {
      lines.push('');
      lines.push('────────────────────────');
      lines.push('');
    }
  });

  lines.push('');
  lines.push('────────────────────────');
  lines.push('');

  // 4. Salam Penutup dan Instruksi Singkat
  lines.push('*Catatan Penting:*');
  lines.push(config.closingInstruction.trim());
  lines.push('');

  if (config.closingSalutation) {
    lines.push(config.closingSalutation.trim());
  }

  if (config.treasurerName) {
    lines.push('');
    lines.push(`*${config.treasurerName}*`);
    if (config.treasurerContact) {
      lines.push(`WA: ${config.treasurerContact}`);
    }
  }

  return lines.join('\n');
}

export const DEFAULT_MESSAGE_CONFIG: MessageConfig = {
  headerGreeting:
    'Bapak/Ibu wali murid yang kami hormati,\nBerikut adalah rekap update pembayaran iuran & kegiatan sekolah:',
  activityTitle: 'REKAP PEMBAYARAN SISWA',
  schoolName: 'SMP / SEKOLAH KITA',
  updateDate: new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date()),
  treasurerName: 'Bendahara Sekolah',
  treasurerContact: '',
  closingInstruction:
    'Bagi Bapak/Ibu yang merasa sudah melakukan pembayaran/transfer namun namanya belum tercatat pada daftar di atas (terutama bila transfer ke rekening pribadi bendahara atau belum sempat konfirmasi), mohon segera mengirimkan bukti transfer via chat WhatsApp ini agar dapat kami periksa dan perbarui segera.',
  closingSalutation:
    'Terima kasih banyak atas kerja sama, perhatian, dan ketepatan waktu Bapak/Ibu sekalian.',
  showAmount: true,
  numberingStyle: 'numeric',
  selectedClassFilter: 'all',
  showEmptyCategories: true,
  includeTariffSchemeInMessage: true,
  paymentTariffs: DEFAULT_TARIFFS,
};
