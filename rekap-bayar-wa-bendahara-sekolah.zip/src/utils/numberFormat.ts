/**
 * Formats a number with Indonesian thousand separator (dot).
 * e.g., 250000 -> "Rp 250.000" or with prefix = "" -> "250.000"
 */
export function formatThousands(value: number): string {
  if (isNaN(value)) return '0';
  return Math.round(value)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, '.');
}

export function formatRupiah(value: number, withPrefix: boolean = true): string {
  if (value === undefined || value === null || isNaN(value)) {
    return withPrefix ? 'Rp 0' : '0';
  }
  const formatted = formatThousands(value);
  return withPrefix ? `Rp ${formatted}` : formatted;
}

/**
 * Parses user input strings into a clean integer amount.
 * Handles formats like:
 * - "250.000"
 * - "250,000"
 * - "Rp 250.000,-"
 * - "150rb" or "150 rb" (150000)
 * - "150k" or "150 k" (150000)
 * - "1jt" or "1.5jt" (1500000)
 */
export function parseNominal(raw: string | number | undefined | null): number {
  if (raw === undefined || raw === null) return 0;
  if (typeof raw === 'number') return Math.max(0, Math.round(raw));

  const text = raw.trim().toLowerCase();
  if (!text) return 0;

  // Check for 'jt' / 'juta' (million)
  const jtMatch = text.match(/([\d.,]+)\s*(?:jt|juta)/);
  if (jtMatch) {
    const val = parseFloat(jtMatch[1].replace(',', '.'));
    if (!isNaN(val)) return Math.round(val * 1000000);
  }

  // Check for 'rb' / 'ribu' / 'k' (thousand)
  const rbMatch = text.match(/([\d.,]+)\s*(?:rb|ribu|k)/);
  if (rbMatch) {
    const val = parseFloat(rbMatch[1].replace(',', '.'));
    if (!isNaN(val)) return Math.round(val * 1000);
  }

  // Strip Rp, letters, spaces, trailing dashes
  const clean = text.replace(/[^0-9]/g, '');
  const parsed = parseInt(clean, 10);
  return isNaN(parsed) ? 0 : parsed;
}
