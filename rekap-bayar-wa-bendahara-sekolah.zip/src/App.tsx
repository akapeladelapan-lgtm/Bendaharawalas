/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { TopQuickActionSection } from './components/TopQuickActionSection';
import { FinancialSummary } from './components/FinancialSummary';
import { RawInputSection } from './components/RawInputSection';
import { StudentTable } from './components/StudentTable';
import { ConfigPanel } from './components/ConfigPanel';
import { WhatsAppPreviewCard } from './components/WhatsAppPreviewCard';
import { RulesModal } from './components/RulesModal';
import { VercelDeployModal } from './components/VercelDeployModal';
import { StudentPayment, MessageConfig } from './types/payment';
import { DEFAULT_MESSAGE_CONFIG } from './utils/whatsappFormatter';
import { parseRawPaymentText } from './utils/textParser';
import { SAMPLE_PRESETS } from './data/samplePresets';
import { FileEdit, Settings, CheckCircle2, AlertCircle, Info, Sparkles } from 'lucide-react';

interface ToastState {
  show: boolean;
  message: string;
  type: 'success' | 'info' | 'error';
}

export default function App() {
  // Initialize with the first realistic preset
  const [students, setStudents] = useState<StudentPayment[]>(() => {
    return parseRawPaymentText(SAMPLE_PRESETS[0].rawText, DEFAULT_MESSAGE_CONFIG.paymentTariffs);
  });

  const [config, setConfig] = useState<MessageConfig>(DEFAULT_MESSAGE_CONFIG);
  const [activeLeftTab, setActiveLeftTab] = useState<'data' | 'config'>('data');
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState<boolean>(false);
  const [isVercelModalOpen, setIsVercelModalOpen] = useState<boolean>(false);

  const [toast, setToast] = useState<ToastState>({
    show: false,
    message: '',
    type: 'success',
  });

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ show: true, message, type });
  };

  useEffect(() => {
    if (toast.show) {
      const timer = setTimeout(() => {
        setToast((prev) => ({ ...prev, show: false }));
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [toast.show]);

  const handleDataParsed = (newStudents: StudentPayment[]) => {
    setStudents(newStudents);
  };

  const handleResetConfig = () => {
    setConfig(DEFAULT_MESSAGE_CONFIG);
    showToast('Format pesan dikembalikan ke standar awal', 'info');
  };

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-800 flex flex-col font-sans">
      {/* Toast Notification */}
      {toast.show && (
        <div className="fixed bottom-5 right-5 z-50 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div
            className={`flex items-center space-x-2.5 px-4 py-3 rounded-2xl shadow-xl text-xs sm:text-sm font-medium border ${
              toast.type === 'success'
                ? 'bg-emerald-900 text-white border-emerald-700'
                : toast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-700'
                : 'bg-slate-900 text-white border-slate-700'
            }`}
          >
            {toast.type === 'success' && (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            {toast.type === 'error' && (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            {toast.type === 'info' && <Info className="w-4 h-4 text-blue-400 shrink-0" />}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <Header
        onOpenRules={() => setIsRulesModalOpen(true)}
        onOpenVercel={() => setIsVercelModalOpen(true)}
      />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full space-y-6">
        {/* FITUR ATAS: Input Cepat Berdasarkan Nama & Status + Impor Nama & Kelas CSV Sekaligus */}
        <TopQuickActionSection
          students={students}
          onUpdateStudents={setStudents}
          showToast={showToast}
          tariffs={config.paymentTariffs}
        />

        {/* Financial & Student Metrics */}
        <FinancialSummary students={students} />

        {/* Two-Column Responsive Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Input, Table Editor, or Settings */}
          <div className="lg:col-span-6 space-y-5">
            {/* View Switcher Tabs */}
            <div className="flex items-center space-x-1.5 p-1 bg-slate-200/80 rounded-xl border border-slate-300/60">
              <button
                type="button"
                onClick={() => setActiveLeftTab('data')}
                className={`flex-1 py-2 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  activeLeftTab === 'data'
                    ? 'bg-white text-emerald-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <FileEdit className="w-4 h-4 text-emerald-600" />
                Data & Tabel Siswa ({students.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveLeftTab('config')}
                className={`flex-1 py-2 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-all flex items-center justify-center gap-1.5 ${
                  activeLeftTab === 'config'
                    ? 'bg-white text-emerald-800 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Settings className="w-4 h-4 text-indigo-600" />
                Format Salam & Instruksi WA
              </button>
            </div>

            {activeLeftTab === 'data' ? (
              <div className="space-y-5">
                {/* Raw Input and Preset Area */}
                <RawInputSection
                  onDataParsed={handleDataParsed}
                  isLoadingAi={isLoadingAi}
                  setIsLoadingAi={setIsLoadingAi}
                  showToast={showToast}
                  tariffs={config.paymentTariffs}
                />

                {/* Interactive Table of Students */}
                <StudentTable
                  students={students}
                  onUpdateStudents={setStudents}
                  showToast={showToast}
                  tariffs={config.paymentTariffs}
                />
              </div>
            ) : (
              /* Message & Rules Config */
              <ConfigPanel
                config={config}
                onChangeConfig={setConfig}
                onResetDefault={handleResetConfig}
              />
            )}
          </div>

          {/* Right Column: Live WhatsApp Preview & 1-Click Copy */}
          <div className="lg:col-span-6 sticky top-6">
            <WhatsAppPreviewCard
              students={students}
              config={config}
              showToast={showToast}
            />
          </div>
        </div>
      </main>

      {/* Rules Explanatory Modal */}
      <RulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
      />

      {/* Vercel Deploy & Public Access Modal */}
      <VercelDeployModal
        isOpen={isVercelModalOpen}
        onClose={() => setIsVercelModalOpen(false)}
        showToast={showToast}
      />

      {/* Footer */}
      <footer className="mt-auto py-5 border-t border-slate-200 bg-white text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>
            Asisten Khusus Bendahara Sekolah • Format WhatsApp Standar Walimurid
          </span>
          <div className="flex items-center space-x-3 text-slate-400">
            <span>✅ LUNAS (Rp 3.350.000)</span>
            <span>•</span>
            <span>⏳ ANGSURAN 1 (Rp 1.700.000)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
