import React from 'react';
import { ShieldCheck, Sparkles, MessageSquare, Info, Globe } from 'lucide-react';

interface HeaderProps {
  onOpenRules: () => void;
  onOpenVercel: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenRules, onOpenVercel }) => {
  return (
    <header className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white shadow-lg border-b border-emerald-600/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="flex items-start sm:items-center space-x-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center shadow-inner text-emerald-200 shrink-0">
              <MessageSquare className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
                  Asisten Bendahara Sekolah
                </h1>
                <span className="hidden sm:inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/25 text-emerald-100 border border-emerald-400/30">
                  <Sparkles className="w-3 h-3 mr-1 text-emerald-300" /> Format WhatsApp Resmi
                </span>
              </div>
              <p className="text-xs sm:text-sm text-emerald-100/90 mt-0.5">
                Konversi data mentah pembayaran siswa menjadi pesan WhatsApp terstruktur, rapi, dan siap salin-tempel
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
            <button
              onClick={onOpenVercel}
              className="inline-flex items-center px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold bg-emerald-950/70 hover:bg-emerald-950 text-white border border-emerald-400/50 transition-all shadow-sm active:scale-95"
            >
              <Globe className="w-4 h-4 mr-1.5 text-emerald-300" />
              🌐 Akses Publik & Vercel
            </button>
            <button
              onClick={onOpenRules}
              className="inline-flex items-center px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all shadow-sm active:scale-95"
            >
              <Info className="w-4 h-4 mr-1.5 text-emerald-300" />
              7 Aturan Format WA
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
