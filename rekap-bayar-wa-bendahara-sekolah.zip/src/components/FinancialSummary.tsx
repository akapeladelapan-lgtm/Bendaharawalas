import React from 'react';
import { CheckCircle2, Clock, Users, Landmark, Layers } from 'lucide-react';
import { StudentPayment } from '../types/payment';
import { formatRupiah } from '../utils/numberFormat';

interface FinancialSummaryProps {
  students: StudentPayment[];
}

export const FinancialSummary: React.FC<FinancialSummaryProps> = ({ students }) => {
  const total = students.length;
  const lunasCount = students.filter((s) => s.status === 'LUNAS').length;
  const angsuranPertamaCount = students.filter((s) => s.status === 'ANGSURAN PERTAMA').length;

  const lunasPercent = total > 0 ? Math.round((lunasCount / total) * 100) : 0;
  const angsuranPertamaPercent = total > 0 ? Math.round((angsuranPertamaCount / total) * 100) : 0;

  const totalFunds = students.reduce((sum, s) => sum + (s.amount || 0), 0);
  const classesSet = new Set(students.map((s) => s.classGrade.trim()).filter(Boolean));

  return (
    <div className="space-y-3">
      {/* Rate scheme pill banner */}
      <div className="bg-emerald-900/5 border border-emerald-600/20 rounded-xl px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2 text-emerald-950 font-semibold">
          <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
          <span>Skema Tarif Pembayaran Resmi:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2 font-mono text-[11px]">
          <span className="bg-white px-3 py-1 rounded-lg border border-orange-200 text-orange-800 shadow-2xs font-medium">
            1. Angsuran Pertama: <strong className="font-bold text-orange-950">Rp 1.700.000</strong>
          </span>
          <span className="bg-white px-3 py-1 rounded-lg border border-emerald-200 text-emerald-800 shadow-2xs font-medium">
            2. Lunas: <strong className="font-bold text-emerald-950">Rp 3.350.000</strong>
          </span>
        </div>
      </div>

      {/* Metric Cards: 4 Clean Columns */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Total Students */}
        <div className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">Total Siswa</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-bold text-slate-800">{total}</span>
            <span className="text-xs text-slate-500">{classesSet.size} kelas</span>
          </div>
        </div>

        {/* LUNAS */}
        <div className="bg-white rounded-2xl p-4 border border-emerald-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-emerald-600">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700">✅ Lunas (3.35jt)</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div>
              <span className="text-2xl font-bold text-emerald-700">{lunasCount}</span>
              <span className="text-xs text-emerald-600 ml-1 font-medium">({lunasPercent}%)</span>
            </div>
            <span className="text-[11px] text-emerald-600/80">Selesai bayar</span>
          </div>
        </div>

        {/* ANGSURAN PERTAMA */}
        <div className="bg-white rounded-2xl p-4 border border-orange-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-orange-600">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-orange-700">⏳ Angsuran 1 (1.7jt)</span>
            <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <div>
              <span className="text-2xl font-bold text-orange-700">{angsuranPertamaCount}</span>
              <span className="text-xs text-orange-600 ml-1 font-medium">({angsuranPertamaPercent}%)</span>
            </div>
            <span className="text-[11px] text-orange-600/80">Tahap awal</span>
          </div>
        </div>

        {/* TOTAL DANA */}
        <div className="bg-white rounded-2xl p-4 border border-teal-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-teal-600">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-teal-700">Dana Terdata</span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
              <Landmark className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-2">
            <div className="text-lg sm:text-xl font-bold text-teal-800 truncate" title={formatRupiah(totalFunds)}>
              {formatRupiah(totalFunds)}
            </div>
            <div className="text-[11px] text-teal-600/80 mt-0.5">Format ribuan titik</div>
          </div>
        </div>
      </div>
    </div>
  );
};
