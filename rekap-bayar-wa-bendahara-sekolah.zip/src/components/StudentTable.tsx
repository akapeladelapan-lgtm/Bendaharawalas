import React, { useState } from 'react';
import {
  Search,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  CheckCircle2,
  Clock,
  Layers,
  ArrowUpRight,
} from 'lucide-react';
import { StudentPayment, PaymentStatus, PaymentTariffs } from '../types/payment';
import { formatRupiah, parseNominal } from '../utils/numberFormat';
import { DEFAULT_TARIFFS, getDefaultTariffForStatus } from '../utils/textParser';

interface StudentTableProps {
  students: StudentPayment[];
  onUpdateStudents: (updated: StudentPayment[]) => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  tariffs?: PaymentTariffs;
}

export const StudentTable: React.FC<StudentTableProps> = ({
  students,
  onUpdateStudents,
  showToast,
  tariffs = DEFAULT_TARIFFS,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [editingId, setEditingId] = useState<string | null>(null);

  // Edit draft state
  const [draftName, setDraftName] = useState('');
  const [draftClass, setDraftClass] = useState('');
  const [draftStatus, setDraftStatus] = useState<PaymentStatus>('LUNAS');
  const [draftAmount, setDraftAmount] = useState('');

  // Add new modal/row state
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newClass, setNewClass] = useState('7A');
  const [newStatus, setNewStatus] = useState<PaymentStatus>('LUNAS');
  const [newAmount, setNewAmount] = useState('3.350.000');

  // Extract unique classes
  const uniqueClasses = Array.from(
    new Set(students.map((s) => s.classGrade.trim().toUpperCase()).filter(Boolean))
  ).sort();

  // Filtered students
  const filtered = students.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.classGrade.toLowerCase().includes(searchTerm.toLowerCase());
    const matchClass =
      filterClass === 'all' || s.classGrade.toUpperCase() === filterClass.toUpperCase();
    const matchStatus = filterStatus === 'all' || s.status === filterStatus;
    return matchSearch && matchClass && matchStatus;
  });

  const handleCycleStatus = (id: string) => {
    const updated = students.map((s) => {
      if (s.id === id) {
        const nextStatus: PaymentStatus =
          s.status === 'LUNAS' ? 'ANGSURAN PERTAMA' : 'LUNAS';
        const nextAmount = getDefaultTariffForStatus(nextStatus, tariffs);
        return { ...s, status: nextStatus, amount: nextAmount };
      }
      return s;
    });
    onUpdateStudents(updated);
  };

  const handleStatusChangeInNewForm = (status: PaymentStatus) => {
    setNewStatus(status);
    const amount = getDefaultTariffForStatus(status, tariffs);
    setNewAmount(formatRupiah(amount, false));
  };

  const handleStartEdit = (student: StudentPayment) => {
    setEditingId(student.id);
    setDraftName(student.name);
    setDraftClass(student.classGrade);
    setDraftStatus(student.status);
    setDraftAmount(student.amount ? String(student.amount) : '');
  };

  const handleSaveEdit = (id: string) => {
    if (!draftName.trim()) {
      showToast('Nama siswa tidak boleh kosong', 'error');
      return;
    }
    const updated = students.map((s) => {
      if (s.id === id) {
        return {
          ...s,
          name: draftName.trim(),
          classGrade: draftClass.trim().toUpperCase() || '7A',
          status: draftStatus,
          amount: draftAmount ? parseNominal(draftAmount) : getDefaultTariffForStatus(draftStatus, tariffs),
        };
      }
      return s;
    });
    onUpdateStudents(updated);
    setEditingId(null);
    showToast('Data siswa diperbarui', 'success');
  };

  const handleDelete = (id: string) => {
    const updated = students.filter((s) => s.id !== id);
    onUpdateStudents(updated);
    showToast('Data siswa dihapus', 'info');
  };

  const handleAddNewStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      showToast('Nama siswa wajib diisi', 'error');
      return;
    }
    const amountVal = newAmount ? parseNominal(newAmount) : getDefaultTariffForStatus(newStatus, tariffs);
    const newStudent: StudentPayment = {
      id: `stu_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: newName.trim(),
      classGrade: newClass.trim().toUpperCase() || '7A',
      status: newStatus,
      amount: amountVal,
    };
    onUpdateStudents([newStudent, ...students]);
    setNewName('');
    setIsAddingNew(false);
    showToast(`Siswa "${newStudent.name}" berhasil ditambahkan!`, 'success');
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
      {/* Top Bar */}
      <div className="px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-50/70">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-teal-600 text-white flex items-center justify-center shadow-xs">
            <Layers className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-base font-semibold text-slate-900">
                Tabel Data Siswa Terverifikasi
              </h2>
              <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-slate-200 text-slate-700">
                {students.length} total
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Klik status untuk berganti cepat: LUNAS ⇄ ANGSURAN 1
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={() => setIsAddingNew(!isAddingNew)}
            className="inline-flex items-center px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg shadow-2xs transition-all active:scale-95"
          >
            <Plus className="w-3.5 h-3.5 mr-1" />
            + Tambah Siswa
          </button>
        </div>
      </div>

      {/* Add New Student Form Inline */}
      {isAddingNew && (
        <form
          onSubmit={handleAddNewStudent}
          className="p-4 bg-emerald-50/50 border-b border-emerald-100 grid grid-cols-1 sm:grid-cols-5 gap-3 items-end"
        >
          <div className="sm:col-span-2">
            <label className="text-[11px] font-semibold uppercase text-slate-600 block mb-1">
              Nama Siswa
            </label>
            <input
              type="text"
              required
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="Contoh: Muhammad Farhan"
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="text-[11px] font-semibold uppercase text-slate-600 block mb-1">
              Kelas
            </label>
            <input
              type="text"
              required
              value={newClass}
              onChange={(e) => setNewClass(e.target.value)}
              placeholder="7A / 7B"
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
          <div>
            <label className="text-[11px] font-semibold uppercase text-slate-600 block mb-1">
              Status
            </label>
            <select
              value={newStatus}
              onChange={(e) => handleStatusChangeInNewForm(e.target.value as PaymentStatus)}
              className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            >
              <option value="LUNAS">✅ LUNAS (Rp 3.350.000)</option>
              <option value="ANGSURAN PERTAMA">⏳ ANGSURAN 1 (Rp 1.700.000)</option>
            </select>
          </div>
          <div className="flex items-center space-x-2">
            <div className="flex-1">
              <label className="text-[11px] font-semibold uppercase text-slate-600 block mb-1">
                Nominal (Rp)
              </label>
              <input
                type="text"
                value={newAmount}
                onChange={(e) => setNewAmount(e.target.value)}
                placeholder="3.350.000"
                className="w-full text-xs bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 focus:ring-1 focus:ring-emerald-500 focus:outline-none font-mono"
              />
            </div>
            <button
              type="submit"
              className="h-8 px-3 mt-4 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-2xs transition-colors self-end"
            >
              Simpan
            </button>
            <button
              type="button"
              onClick={() => setIsAddingNew(false)}
              className="h-8 px-2 mt-4 text-xs font-semibold text-slate-500 hover:text-slate-700 bg-white border border-slate-200 rounded-lg self-end"
            >
              Batal
            </button>
          </div>
        </form>
      )}

      {/* Filter and Search Bar */}
      <div className="p-3.5 border-b border-slate-100 bg-white flex flex-col md:flex-row items-stretch md:items-center justify-between gap-2.5">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Cari nama siswa atau kelas..."
            className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        <div className="flex items-center space-x-2">
          {/* Class Filter */}
          <select
            value={filterClass}
            onChange={(e) => setFilterClass(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Semua Kelas ({uniqueClasses.length})</option>
            {uniqueClasses.map((cls) => (
              <option key={cls} value={cls}>
                Kelas {cls}
              </option>
            ))}
          </select>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          >
            <option value="all">Semua Status</option>
            <option value="LUNAS">✅ Lunas (3.35jt)</option>
            <option value="ANGSURAN PERTAMA">⏳ Angsuran 1 (1.7jt)</option>
          </select>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto max-h-[380px]">
        {filtered.length === 0 ? (
          <div className="text-center py-10 px-4 text-slate-400">
            <p className="text-sm">Tidak ada data siswa yang cocok dengan filter atau pencarian.</p>
          </div>
        ) : (
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold sticky top-0 z-10 border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-3.5 w-12 text-center">No</th>
                <th className="py-2.5 px-3.5">Nama Siswa</th>
                <th className="py-2.5 px-3.5 w-24">Kelas</th>
                <th className="py-2.5 px-3.5 w-48">Status Pembayaran</th>
                <th className="py-2.5 px-3.5 w-32">Nominal</th>
                <th className="py-2.5 px-3.5 w-20 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filtered.map((student, idx) => {
                const isEditing = editingId === student.id;

                if (isEditing) {
                  return (
                    <tr key={student.id} className="bg-amber-50/50">
                      <td className="py-2 px-3 text-center text-slate-400">{idx + 1}</td>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={draftName}
                          onChange={(e) => setDraftName(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs"
                          autoFocus
                        />
                      </td>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={draftClass}
                          onChange={(e) => setDraftClass(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs uppercase"
                        />
                      </td>
                      <td className="py-2 px-3">
                        <select
                          value={draftStatus}
                          onChange={(e) => {
                            const st = e.target.value as PaymentStatus;
                            setDraftStatus(st);
                            setDraftAmount(String(getDefaultTariffForStatus(st, tariffs)));
                          }}
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs"
                        >
                          <option value="LUNAS">✅ LUNAS (Rp 3.350.000)</option>
                          <option value="ANGSURAN PERTAMA">⏳ ANGSURAN 1 (Rp 1.700.000)</option>
                        </select>
                      </td>
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={draftAmount}
                          onChange={(e) => setDraftAmount(e.target.value)}
                          placeholder="Nominal"
                          className="w-full bg-white border border-slate-300 rounded px-2 py-1 text-xs font-mono"
                        />
                      </td>
                      <td className="py-2 px-3 text-center">
                        <div className="flex items-center justify-center space-x-1">
                          <button
                            onClick={() => handleSaveEdit(student.id)}
                            className="p-1 text-emerald-600 hover:bg-emerald-100 rounded"
                            title="Simpan"
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            title="Batal"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr
                    key={student.id}
                    className="hover:bg-slate-50/70 transition-colors group"
                  >
                    <td className="py-2.5 px-3.5 text-center text-slate-400 font-mono">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3.5 font-medium text-slate-900">
                      {student.name}
                      {student.notes && (
                        <span className="block text-[11px] text-slate-400 italic font-normal">
                          {student.notes}
                        </span>
                      )}
                    </td>
                    <td className="py-2.5 px-3.5">
                      <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-semibold bg-slate-100 text-slate-700">
                        {student.classGrade}
                      </span>
                    </td>
                    <td className="py-2.5 px-3.5">
                      <button
                        type="button"
                        onClick={() => handleCycleStatus(student.id)}
                        className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold cursor-pointer transition-all active:scale-95 border ${
                          student.status === 'LUNAS'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                            : 'bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100'
                        }`}
                        title="Klik untuk beralih status: LUNAS ⇄ ANGSURAN 1"
                      >
                        {student.status === 'LUNAS' ? (
                          <>
                            <CheckCircle2 className="w-3 h-3 mr-1 text-emerald-600" />
                            LUNAS
                          </>
                        ) : (
                          <>
                            <Clock className="w-3 h-3 mr-1 text-orange-600" />
                            ANGSURAN 1
                          </>
                        )}
                      </button>
                    </td>
                    <td className="py-2.5 px-3.5 font-mono text-slate-700">
                      {student.amount !== undefined && student.amount > 0 ? (
                        <span className="font-medium text-slate-800">
                          {formatRupiah(student.amount)}
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3.5 text-center">
                      <div className="flex items-center justify-center space-x-1 opacity-70 group-hover:opacity-100 transition-opacity">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(student)}
                          className="p-1 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                          title="Edit baris ini"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(student.id)}
                          className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                          title="Hapus baris ini"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};
