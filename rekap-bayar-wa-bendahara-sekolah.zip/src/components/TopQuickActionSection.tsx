import React, { useState, useMemo, useRef } from 'react';
import {
  Zap,
  Upload,
  UserCheck,
  FileSpreadsheet,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  Plus,
  Search,
  Download,
  AlertCircle,
  FileText,
  RefreshCw,
} from 'lucide-react';
import { StudentPayment, PaymentStatus, PaymentTariffs } from '../types/payment';
import { formatRupiah, parseNominal } from '../utils/numberFormat';
import { getDefaultTariffForStatus } from '../utils/textParser';
import { parseCsvStudents } from '../utils/csvParser';

interface TopQuickActionSectionProps {
  students: StudentPayment[];
  onUpdateStudents: (updated: StudentPayment[]) => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  tariffs: PaymentTariffs;
}

export const TopQuickActionSection: React.FC<TopQuickActionSectionProps> = ({
  students,
  onUpdateStudents,
  showToast,
  tariffs,
}) => {
  const [activeTab, setActiveTab] = useState<'quick_payment' | 'bulk_csv'>('quick_payment');

  // --- STATE FOR QUICK PAYMENT INPUT ---
  const [studentName, setStudentName] = useState('');
  const [selectedClass, setSelectedClass] = useState('7A');
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>('LUNAS');
  const [amountStr, setAmountStr] = useState<string>(formatRupiah(tariffs.lunas, false));
  const [notes, setNotes] = useState('');
  const [isSuggestOpen, setIsSuggestOpen] = useState(false);

  // --- STATE FOR CSV / BULK INPUT ---
  const [csvText, setCsvText] = useState(
    `Ahmad Dahlan, 7A
Dewi Sartika, 7A
Ki Hajar Dewantara, 7B
Raden Ajeng Kartini, 7B
Sultan Hasanuddin, 8A
Cut Nyak Dien, 8A`
  );
  const [csvDefaultStatus, setCsvDefaultStatus] = useState<PaymentStatus>('ANGSURAN PERTAMA');
  const [csvImportMode, setCsvImportMode] = useState<'append' | 'replace'>('append');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Available unique classes from existing data
  const existingClasses = useMemo(() => {
    const set = new Set(students.map((s) => s.classGrade.trim().toUpperCase()).filter(Boolean));
    if (set.size === 0) return ['7A', '7B', '8A', '8B', '9A'];
    return Array.from(set).sort();
  }, [students]);

  // Autocomplete matching existing students
  const filteredSuggestions = useMemo(() => {
    if (!studentName.trim() || studentName.length < 2) return [];
    const query = studentName.toLowerCase();
    return students.filter((s) => s.name.toLowerCase().includes(query)).slice(0, 5);
  }, [studentName, students]);

  // Check if current typed student already exists
  const existingStudent = useMemo(() => {
    if (!studentName.trim()) return null;
    return students.find((s) => s.name.toLowerCase() === studentName.trim().toLowerCase());
  }, [studentName, students]);

  // When status changes in Quick Payment, sync default tariff amount
  const handleStatusChange = (status: PaymentStatus) => {
    setPaymentStatus(status);
    const amount = getDefaultTariffForStatus(status, tariffs);
    setAmountStr(formatRupiah(amount, false));
  };

  const handleSelectSuggestion = (student: StudentPayment) => {
    setStudentName(student.name);
    setSelectedClass(student.classGrade);
    setPaymentStatus(student.status);
    setAmountStr(formatRupiah(student.amount || getDefaultTariffForStatus(student.status, tariffs), false));
    if (student.notes) setNotes(student.notes);
    setIsSuggestOpen(false);
  };

  const handleSaveQuickPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = studentName.trim();
    if (!cleanName) {
      showToast('Nama siswa wajib diisi.', 'error');
      return;
    }

    const nominalValue = amountStr ? parseNominal(amountStr) : getDefaultTariffForStatus(paymentStatus, tariffs);
    const cleanClass = selectedClass.trim().toUpperCase() || '7A';

    // Check if student already exists -> Update!
    const existingIndex = students.findIndex(
      (s) => s.name.toLowerCase() === cleanName.toLowerCase()
    );

    let updated: StudentPayment[];
    if (existingIndex >= 0) {
      // Update existing record
      updated = [...students];
      updated[existingIndex] = {
        ...updated[existingIndex],
        classGrade: cleanClass,
        status: paymentStatus,
        amount: nominalValue,
        notes: notes.trim() || undefined,
      };
      showToast(`Berhasil memperbarui pembayaran "${cleanName}" (${cleanClass}) menjadi ${paymentStatus} - ${formatRupiah(nominalValue)}!`, 'success');
    } else {
      // Add new record at the top
      const newRecord: StudentPayment = {
        id: `stu_quick_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        name: cleanName,
        classGrade: cleanClass,
        status: paymentStatus,
        amount: nominalValue,
        notes: notes.trim() || undefined,
      };
      updated = [newRecord, ...students];
      showToast(`Berhasil mencatat pembayaran baru untuk "${cleanName}" (${cleanClass})!`, 'success');
    }

    onUpdateStudents(updated);
    setStudentName('');
    setNotes('');
  };

  // --- CSV ACTIONS ---
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        setCsvText(content);
        showToast(`File "${file.name}" berhasil dimuat ke editor CSV`, 'info');
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDownloadCsvTemplate = () => {
    const templateContent = `Nama,Kelas,Status,Nominal
Ahmad Fauzi,7A,Lunas,3350000
Budi Santoso,7A,Angsuran Pertama,1700000
Citra Kirana,7A,Lunas,3350000
Dimas Anggara,7B,Angsuran Pertama,1700000
Eka Prasetya,7B,Lunas,3350000`;

    const blob = new Blob([templateContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Template_Nama_Kelas_Siswa.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Template CSV berhasil diunduh', 'success');
  };

  const previewCount = useMemo(() => {
    return parseCsvStudents(csvText, csvDefaultStatus, tariffs).length;
  }, [csvText, csvDefaultStatus, tariffs]);

  const handleProcessCsvImport = () => {
    const parsed = parseCsvStudents(csvText, csvDefaultStatus, tariffs);
    if (parsed.length === 0) {
      showToast('Tidak ada data siswa yang valid ditemukan dalam teks CSV.', 'error');
      return;
    }

    if (csvImportMode === 'replace') {
      onUpdateStudents(parsed);
      showToast(`Berhasil mengganti database dengan ${parsed.length} siswa dari CSV!`, 'success');
    } else {
      // Append, avoiding exact duplicate name & class
      const existingKeySet = new Set(students.map((s) => `${s.name.toLowerCase()}_${s.classGrade.toLowerCase()}`));
      const newItems = parsed.filter((s) => !existingKeySet.has(`${s.name.toLowerCase()}_${s.classGrade.toLowerCase()}`));
      const combined = [...students, ...newItems];
      onUpdateStudents(combined);
      showToast(`Berhasil menambahkan ${newItems.length} siswa baru dari CSV (Total: ${combined.length})!`, 'success');
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-emerald-500/30 shadow-md overflow-hidden ring-1 ring-emerald-500/20">
      {/* Top Banner Navigation */}
      <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white px-5 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center text-white shadow-inner">
            <Zap className="w-4 h-4 text-emerald-200" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-bold tracking-tight">
              Akses Cepat Bendahara: Input Pembayaran & Impor Siswa
            </h2>
            <p className="text-[11px] text-emerald-100/90">
              Catat per siswa secara instan atau masukkan nama & kelas sekaligus (format CSV)
            </p>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex items-center space-x-1.5 p-1 bg-emerald-950/40 rounded-xl border border-emerald-500/30 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('quick_payment')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'quick_payment'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-emerald-200 hover:text-white'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            Input Cepat Pembayaran
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('bulk_csv')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'bulk_csv'
                ? 'bg-white text-emerald-900 shadow-xs'
                : 'text-emerald-200 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Impor CSV / Sekaligus
          </button>
        </div>
      </div>

      {/* Content for Tab 1: Input Pembayaran Berdasarkan Nama dan Status */}
      {activeTab === 'quick_payment' && (
        <form onSubmit={handleSaveQuickPayment} className="p-4 sm:p-5 bg-gradient-to-b from-emerald-50/40 to-white">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5 items-start">
            {/* Nama Siswa (Searchable & Autocomplete) */}
            <div className="md:col-span-4 relative">
              <label className="text-xs font-semibold text-slate-700 flex items-center justify-between mb-1">
                <span>Nama Siswa *</span>
                {existingStudent && (
                  <span className="text-[10px] text-blue-600 font-normal bg-blue-50 px-1.5 py-0.5 rounded border border-blue-200">
                    Siswa terdaftar: akan diperbarui
                  </span>
                )}
              </label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={studentName}
                  onChange={(e) => {
                    setStudentName(e.target.value);
                    setIsSuggestOpen(true);
                  }}
                  onFocus={() => setIsSuggestOpen(true)}
                  placeholder="Ketik nama siswa..."
                  className="w-full text-xs sm:text-sm bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-800 placeholder-slate-400 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5 pointer-events-none" />
              </div>

              {/* Suggestions Dropdown */}
              {isSuggestOpen && filteredSuggestions.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-1 divide-y divide-slate-100 max-h-48 overflow-y-auto text-xs">
                  <div className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase bg-slate-50">
                    Pilih siswa terdaftar:
                  </div>
                  {filteredSuggestions.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => handleSelectSuggestion(s)}
                      className="w-full text-left px-3 py-2 hover:bg-emerald-50 flex items-center justify-between transition-colors"
                    >
                      <div>
                        <span className="font-semibold text-slate-900">{s.name}</span>
                        <span className="ml-2 text-slate-500">Kelas {s.classGrade}</span>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded">
                        {s.status}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Kelas */}
            <div className="md:col-span-2">
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Kelas *
              </label>
              <div className="flex gap-1.5">
                <input
                  type="text"
                  required
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value.toUpperCase())}
                  placeholder="7A / 8B"
                  className="w-full text-xs sm:text-sm bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-800 uppercase font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Status Pembayaran (2 Quick Buttons: Angsuran 1 & Lunas) */}
            <div className="md:col-span-6">
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Pilih Status Pembayaran *
              </label>
              <div className="grid grid-cols-2 gap-2">
                {/* 1. Angsuran Pertama */}
                <button
                  type="button"
                  onClick={() => handleStatusChange('ANGSURAN PERTAMA')}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    paymentStatus === 'ANGSURAN PERTAMA'
                      ? 'bg-orange-600 text-white border-orange-600 shadow-xs ring-1 ring-orange-500 font-semibold'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-orange-300 hover:bg-orange-50/50'
                  }`}
                >
                  <div className="flex items-center text-xs leading-tight font-semibold">
                    <Clock className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                    <span>⏳ 1. Angsuran Pertama</span>
                  </div>
                  <div className={`text-[11px] font-mono mt-0.5 ${paymentStatus === 'ANGSURAN PERTAMA' ? 'text-orange-100' : 'text-slate-500'}`}>
                    {formatRupiah(tariffs.angsuranPertama)}
                  </div>
                </button>

                {/* 2. Lunas */}
                <button
                  type="button"
                  onClick={() => handleStatusChange('LUNAS')}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    paymentStatus === 'LUNAS'
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs ring-1 ring-emerald-500 font-semibold'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-300 hover:bg-emerald-50/50'
                  }`}
                >
                  <div className="flex items-center text-xs leading-tight font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                    <span>✅ 2. Lunas</span>
                  </div>
                  <div className={`text-[11px] font-mono mt-0.5 ${paymentStatus === 'LUNAS' ? 'text-emerald-100' : 'text-slate-500'}`}>
                    {formatRupiah(tariffs.lunas)}
                  </div>
                </button>
              </div>
            </div>
          </div>

          {/* Row 2: Nominal, Catatan & Tombol Simpan */}
          <div className="mt-3.5 pt-3 border-t border-emerald-200/60 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto">
              <div className="flex items-center space-x-1.5">
                <span className="text-xs font-semibold text-slate-600">Nominal:</span>
                <div className="relative">
                  <span className="absolute left-2.5 top-1.5 text-xs text-slate-400 font-mono">Rp</span>
                  <input
                    type="text"
                    value={amountStr}
                    onChange={(e) => setAmountStr(e.target.value)}
                    placeholder="1.700.000"
                    className="w-36 text-xs font-mono font-bold pl-8 pr-2.5 py-1.5 bg-white border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center space-x-1.5 flex-1 sm:flex-none">
                <span className="text-xs text-slate-500">Ket:</span>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Catatan opsional (trf bca, tunai)"
                  className="w-full sm:w-56 text-xs px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto inline-flex items-center justify-center px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs hover:shadow-md transition-all active:scale-95"
            >
              <CheckCircle2 className="w-4 h-4 mr-1.5 text-emerald-300" />
              {existingStudent ? 'Perbarui Data Pembayaran' : '+ Catat Pembayaran'}
            </button>
          </div>
        </form>
      )}

      {/* Content for Tab 2: Input Nama & Kelas dalam Format CSV / Sekaligus */}
      {activeTab === 'bulk_csv' && (
        <div className="p-4 sm:p-5 bg-slate-50/60 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5">
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                Impor Daftar Siswa & Kelas Sekaligus (CSV)
              </h3>
              <p className="text-xs text-slate-500">
                Tempel format baris <code className="bg-slate-200 px-1 py-0.5 rounded text-slate-800">Nama Siswa, Kelas</code> atau unggah file .csv
              </p>
            </div>

            <div className="flex items-center space-x-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.txt,.tsv"
                onChange={handleFileUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg shadow-2xs transition-colors"
              >
                <Upload className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                Unggah File .CSV
              </button>
              <button
                type="button"
                onClick={handleDownloadCsvTemplate}
                className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
                title="Unduh contoh template file CSV"
              >
                <Download className="w-3.5 h-3.5 mr-1" />
                Template CSV
              </button>
            </div>
          </div>

          {/* Textarea for CSV */}
          <div className="relative">
            <textarea
              value={csvText}
              onChange={(e) => setCsvText(e.target.value)}
              placeholder="Contoh:
Ahmad Dahlan, 7A
Dewi Sartika, 7A
Ki Hajar Dewantara, 7B"
              rows={5}
              className="w-full font-mono text-xs sm:text-sm bg-white border border-slate-300 rounded-xl p-3 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <div className="absolute right-3 bottom-3 text-[11px] text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded-md border border-slate-300 font-semibold shadow-2xs">
              Terdeteksi: {previewCount} Siswa
            </div>
          </div>

          {/* Configuration for the Import */}
          <div className="bg-white p-3.5 rounded-xl border border-slate-200 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
            {/* Default Status Selection */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-semibold text-slate-700">Status Pembayaran Default:</span>
              <select
                value={csvDefaultStatus}
                onChange={(e) => setCsvDefaultStatus(e.target.value as PaymentStatus)}
                className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 text-slate-800 font-medium focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              >
                <option value="ANGSURAN PERTAMA">⏳ 1. Angsuran Pertama (Rp 1.700.000)</option>
                <option value="LUNAS">✅ 2. Lunas (Rp 3.350.000)</option>
              </select>
            </div>

            {/* Import Mode Radio */}
            <div className="flex items-center space-x-3 text-slate-600">
              <label className="inline-flex items-center cursor-pointer select-none">
                <input
                  type="radio"
                  name="csvMode"
                  value="append"
                  checked={csvImportMode === 'append'}
                  onChange={() => setCsvImportMode('append')}
                  className="w-3.5 h-3.5 text-emerald-600 focus:ring-emerald-500"
                />
                <span className="ml-1.5 font-medium text-slate-700">Tambahkan ke daftar</span>
              </label>

              <label className="inline-flex items-center cursor-pointer select-none">
                <input
                  type="radio"
                  name="csvMode"
                  value="replace"
                  checked={csvImportMode === 'replace'}
                  onChange={() => setCsvImportMode('replace')}
                  className="w-3.5 h-3.5 text-rose-600 focus:ring-rose-500"
                />
                <span className="ml-1.5 font-medium text-slate-700">Gantikan seluruh data</span>
              </label>
            </div>

            {/* Execute Import Button */}
            <button
              type="button"
              onClick={handleProcessCsvImport}
              className="w-full md:w-auto inline-flex items-center justify-center px-4 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-all active:scale-95"
            >
              <Upload className="w-3.5 h-3.5 mr-1.5" />
              Impor {previewCount} Siswa Sekarang
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
