import React from 'react';
import { X, CheckCircle2, ShieldCheck, Sparkles, BookOpen } from 'lucide-react';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const rules = [
    {
      num: 1,
      title: 'Pengelompokan Berdasarkan Kelas Berurutan',
      desc: 'Data disortir secara alfabetis/numerik (misal Kelas 7A, 7B, 8A, dst.) agar tertib dan mudah dicari oleh wali murid masing-masing kelas.',
    },
    {
      num: 2,
      title: 'Dua Kategori Status: ✅ LUNAS & ⏳ ANGSURAN PERTAMA',
      desc: 'Di dalam setiap kelas, siswa dikelompokkan hanya menjadi dua status: ✅ Lunas (Rp 3.350.000) dan ⏳ Angsuran Pertama (Rp 1.700.000).',
    },
    {
      num: 3,
      title: 'Format *Bold* pada Judul Kelas & Status',
      desc: 'Menggunakan tanda bintang ganda WhatsApp (*KELAS 7A*, *✅ LUNAS*, *⏳ ANGSURAN PERTAMA*) agar langsung tebal di obrolan WA.',
    },
    {
      num: 4,
      title: 'Salam Pembuka Sopan & Profesional',
      desc: 'Mencantumkan sapaan hangat kepada Bapak/Ibu wali murid serta informasi perihal pembayaran dan tanggal rekapitulasi.',
    },
    {
      num: 5,
      title: 'Instruksi Transfer Belum Tercatat / Rekening Pribadi Bendahara',
      desc: 'Salam penutup dilengkapi instruksi jelas bagi wali murid yang sudah transfer namun belum tercantum (misal masuk ke rekening pribadi bendahara atau belum verifikasi) agar segera mengirimkan bukti transfer via japri WA.',
    },
    {
      num: 6,
      title: 'Bebas dari Basa-Basi AI',
      desc: 'Hasil rekapitulasi murni berfokus pada format pesan WhatsApp yang siap salin-tempel tanpa teks pengantar AI yang tidak perlu.',
    },
    {
      num: 7,
      title: 'Format Angka Ribuan dengan Titik Pemisah',
      desc: 'Semua nominal disajikan dalam standar angka rupiah Indonesia dengan titik pemisah ribuan (contoh: Rp 500.000 atau Rp 250.000).',
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-emerald-800 to-teal-800 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                7 Aturan Standar Format WhatsApp Bendahara
              </h3>
              <p className="text-xs text-emerald-100">
                Pedoman format pesan resmi pengumuman pembayaran sekolah
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-3.5 text-xs sm:text-sm">
          {rules.map((r) => (
            <div
              key={r.num}
              className="flex items-start space-x-3 p-3 rounded-xl border border-slate-100 bg-slate-50/70 hover:bg-emerald-50/40 hover:border-emerald-200 transition-all"
            >
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                {r.num}
              </div>
              <div className="flex-1">
                <div className="font-semibold text-slate-800 flex items-center">
                  {r.title}
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 ml-1.5" />
                </div>
                <p className="text-slate-600 text-xs mt-0.5 leading-relaxed">
                  {r.desc}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Aplikasi secara otomatis menerapkan seluruh aturan di atas.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-xl shadow-xs transition-colors"
          >
            Mengerti & Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
