import React, { useState } from 'react';
import {
  FileText,
  Sparkles,
  ClipboardPaste,
  Trash2,
  HelpCircle,
  CheckCircle,
  Loader2,
} from 'lucide-react';
import { SAMPLE_PRESETS, SamplePreset } from '../data/samplePresets';
import { parseRawPaymentText, DEFAULT_TARIFFS } from '../utils/textParser';
import { StudentPayment, PaymentTariffs, PaymentStatus } from '../types/payment';

interface RawInputSectionProps {
  onDataParsed: (students: StudentPayment[], sourceCount: number) => void;
  isLoadingAi: boolean;
  setIsLoadingAi: (loading: boolean) => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  tariffs?: PaymentTariffs;
}

export const RawInputSection: React.FC<RawInputSectionProps> = ({
  onDataParsed,
  isLoadingAi,
  setIsLoadingAi,
  showToast,
  tariffs = DEFAULT_TARIFFS,
}) => {
  const [rawText, setRawText] = useState<string>(SAMPLE_PRESETS[0].rawText);
  const [selectedPresetId, setSelectedPresetId] = useState<string>('skema-resmi-sekolah');

  const handleApplyPreset = (preset: SamplePreset) => {
    setSelectedPresetId(preset.id);
    setRawText(preset.rawText);
    const parsed = parseRawPaymentText(preset.rawText, tariffs);
    onDataParsed(parsed, parsed.length);
    showToast(`Memuat ${preset.title} (${parsed.length} siswa)`, 'info');
  };

  const handleInstantParse = () => {
    if (!rawText.trim()) {
      showToast('Silakan tempel atau masukkan data terlebih dahulu.', 'error');
      return;
    }
    const parsed = parseRawPaymentText(rawText, tariffs);
    if (parsed.length === 0) {
      showToast('Tidak ada data siswa yang terdeteksi. Coba format lain atau gunakan AI.', 'error');
      return;
    }
    onDataParsed(parsed, parsed.length);
    showToast(`Berhasil memproses ${parsed.length} data siswa secara instan!`, 'success');
  };

  const handleAiParse = async () => {
    if (!rawText.trim()) {
      showToast('Silakan tempel atau ketik teks pembayaran terlebih dahulu.', 'error');
      return;
    }

    setIsLoadingAi(true);
    try {
      const res = await fetch('/api/parse-payments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Gagal memproses data dengan AI');
      }

      if (data.students && Array.isArray(data.students) && data.students.length > 0) {
        const mapped: StudentPayment[] = data.students.map((item: any, idx: number) => {
          let status: PaymentStatus = 'LUNAS';
          const rawSt = String(item.status || '').toUpperCase();
          if (rawSt.includes('PERTAMA') || rawSt.includes('1') || rawSt.includes('CICIL') || rawSt.includes('ANGSUR')) {
            status = 'ANGSURAN PERTAMA';
          }

          let amount = item.amount;
          if (!amount || amount === 0) {
            amount = status === 'ANGSURAN PERTAMA' ? tariffs.angsuranPertama : tariffs.lunas;
          }

          return {
            id: `stu_ai_${Date.now()}_${idx}`,
            name: item.name,
            classGrade: item.classGrade || '7A',
            status,
            amount: amount > 0 ? amount : undefined,
            notes: item.notes || undefined,
          };
        });
        onDataParsed(mapped, mapped.length);
        showToast(`✨ AI berhasil mengekstrak ${mapped.length} data siswa!`, 'success');
      } else {
        const localParsed = parseRawPaymentText(rawText, tariffs);
        onDataParsed(localParsed, localParsed.length);
        showToast(`Menggunakan ekstraksi cepat lokal (${localParsed.length} siswa).`, 'info');
      }
    } catch (err: any) {
      console.warn('AI parse failed, falling back to local regex:', err);
      const fallback = parseRawPaymentText(rawText, tariffs);
      if (fallback.length > 0) {
        onDataParsed(fallback, fallback.length);
        showToast(`Menggunakan ekstraksi cepat lokal (${fallback.length} siswa).`, 'info');
      } else {
        showToast(err.message || 'Gagal memproses data.', 'error');
      }
    } finally {
      setIsLoadingAi(false);
    }
  };

  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setRawText(text);
        setSelectedPresetId('');
        const parsed = parseRawPaymentText(text, tariffs);
        if (parsed.length > 0) {
          onDataParsed(parsed, parsed.length);
          showToast(`Berhasil menempel dan membaca ${parsed.length} siswa!`, 'success');
        } else {
          showToast('Data berhasil ditempel dari clipboard.', 'info');
        }
      }
    } catch {
      showToast('Gunakan Ctrl+V atau Cmd+V pada kotak teks untuk menempel.', 'info');
    }
  };

  const handleClear = () => {
    setRawText('');
    setSelectedPresetId('');
    onDataParsed([], 0);
    showToast('Kotak input dibersihkan', 'info');
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-5 py-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-50/70">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
            <FileText className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Input Data Mentah Pembayaran
            </h2>
            <p className="text-xs text-slate-500">
              Salin dari Excel, Google Sheets, pesan WA, atau catatan manual
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={handlePasteClipboard}
            className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs transition-colors"
          >
            <ClipboardPaste className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
            Tempel dari Clipboard
          </button>
          {rawText && (
            <button
              type="button"
              onClick={handleClear}
              className="inline-flex items-center px-2.5 py-1.5 text-xs font-medium text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100/70 rounded-lg transition-colors"
              title="Bersihkan teks"
            >
              <Trash2 className="w-3.5 h-3.5 mr-1" />
              Reset
            </button>
          )}
        </div>
      </div>

      <div className="p-5 space-y-4">
        {/* Preset Selector */}
        <div>
          <label className="text-xs font-semibold uppercase tracking-wider text-slate-500 block mb-2">
            Pilihan Contoh Data Siap Pakai:
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {SAMPLE_PRESETS.map((preset) => {
              const active = selectedPresetId === preset.id;
              return (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => handleApplyPreset(preset)}
                  className={`text-left p-2.5 rounded-xl border text-xs transition-all ${
                    active
                      ? 'border-emerald-500 bg-emerald-50/60 text-emerald-950 ring-1 ring-emerald-500 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50/80 text-slate-700'
                  }`}
                >
                  <div className="font-semibold truncate">{preset.title}</div>
                  <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                    {preset.description}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Textarea */}
        <div className="relative">
          <textarea
            value={rawText}
            onChange={(e) => {
              setRawText(e.target.value);
              setSelectedPresetId('');
            }}
            placeholder={`Contoh format:
Ahmad Fauzi\t7A\tLUNAS\t3.350.000
Budi Santoso\t7A\tAngsuran Pertama\t1.700.000
Citra Kirana\t7A\tLunas\t3.350.000
Dimas Pratama - 7B - Angsuran 1`}
            rows={7}
            className="w-full font-mono text-xs sm:text-sm bg-slate-50/50 border border-slate-200 rounded-xl p-3.5 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
          />
          <div className="absolute right-3 bottom-3 text-[11px] text-slate-400 bg-white/90 px-2 py-0.5 rounded-md border border-slate-200 shadow-2xs">
            {rawText ? `${rawText.split('\n').filter(Boolean).length} baris` : 'Kosong'}
          </div>
        </div>

        {/* Supported formats hint */}
        <div className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-xs text-slate-600">
          <HelpCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold text-slate-700">Skema Status: </span>
            Otomatis mengenali <span className="font-semibold text-orange-700">1. Angsuran Pertama (Rp 1.700.000)</span> dan{' '}
            <span className="font-semibold text-emerald-700">2. Lunas (Rp 3.350.000)</span>. Jika nominal tidak diketik, otomatis terisi sesuai tarif resmi.
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-1">
          <div className="text-xs text-slate-500 w-full sm:w-auto text-center sm:text-left">
            Data akan dikelompokkan per kelas dan status secara otomatis.
          </div>

          <div className="flex items-center space-x-2.5 w-full sm:w-auto justify-end">
            <button
              type="button"
              onClick={handleInstantParse}
              className="flex-1 sm:flex-none inline-flex items-center justify-center px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs hover:shadow-md transition-all active:scale-95"
            >
              <CheckCircle className="w-4 h-4 mr-1.5" />
              Proses Instan
            </button>

            <button
              type="button"
              onClick={handleAiParse}
              disabled={isLoadingAi}
              className="flex-1 sm:flex-none inline-flex items-center justify-center px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-xs hover:shadow-md transition-all active:scale-95 disabled:opacity-60"
            >
              {isLoadingAi ? (
                <>
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  Menganalisis...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-1.5 text-yellow-300" />
                  AI Smart Parse
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
