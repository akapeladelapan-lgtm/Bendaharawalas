import React, { useState } from 'react';
import {
  X,
  Globe,
  GitBranch,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Zap,
  ArrowRight,
  Terminal,
} from 'lucide-react';

interface VercelDeployModalProps {
  isOpen: boolean;
  onClose: () => void;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const VercelDeployModal: React.FC<VercelDeployModalProps> = ({
  isOpen,
  onClose,
  showToast,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCommand, setCopiedCommand] = useState(false);

  if (!isOpen) return null;

  // The permanent Cloud Run URL for public sharing
  const sharedUrl = 'https://ais-pre-xkp3b2nwynpowdvdqcsoze-661290591163.asia-southeast1.run.app';

  const gitCommands = `# 1. Inisialisasi & Push ke GitHub Anda
git init
git add .
git commit -m "feat: Asisten Bendahara Sekolah"
git branch -M main
git remote add origin https://github.com/USERNAME/bendahara-sekolah.git
git push -u origin main`;

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(sharedUrl);
      setCopiedLink(true);
      showToast('Tautan publik berhasil disalin!', 'success');
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      showToast('Gagal menyalin tautan.', 'error');
    }
  };

  const handleCopyCommands = async () => {
    try {
      await navigator.clipboard.writeText(gitCommands);
      setCopiedCommand(true);
      showToast('Perintah Git berhasil disalin!', 'success');
      setTimeout(() => setCopiedCommand(false), 2500);
    } catch {
      showToast('Gagal menyalin perintah Git.', 'error');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center">
              <Globe className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg flex items-center gap-2">
                Akses Publik Umum & Auto Update Vercel
              </h3>
              <p className="text-xs text-slate-300">
                Aplikasi siap diakses online oleh siapa saja dan terintegrasi CI/CD Vercel
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs sm:text-sm">
          {/* Section 1: Direct Public URL (Already Live!) */}
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-emerald-950 flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                1. Tautan Publik Siap Akses (Sudah Live)
              </span>
              <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                Cloud Run Online
              </span>
            </div>
            <p className="text-xs text-slate-600 mb-2.5">
              Aplikasi ini sudah aktif online dan dapat diakses publik oleh guru, bendahara, atau wali murid di seluruh Indonesia:
            </p>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={sharedUrl}
                className="w-full text-xs font-mono bg-white border border-emerald-300 rounded-lg px-3 py-2 text-emerald-900 select-all"
              />
              <button
                type="button"
                onClick={handleCopyUrl}
                className="shrink-0 px-3 py-2 text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg transition-colors flex items-center gap-1"
              >
                {copiedLink ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedLink ? 'Tersalin' : 'Salin'}
              </button>
              <a
                href={sharedUrl}
                target="_blank"
                rel="noreferrer"
                className="shrink-0 p-2 text-emerald-700 bg-white hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors"
                title="Buka web publik"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Section 2: Vercel Auto Update Guide */}
          <div className="space-y-3">
            <h4 className="font-bold text-slate-900 flex items-center gap-2 text-sm">
              <Zap className="w-4 h-4 text-emerald-600" />
              2. Pasang Auto Update dengan Vercel (CI/CD Otomatis)
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              File konfigurasi <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-mono">vercel.json</code> dan serverless function <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-800 font-mono">/api/parse-payments.ts</code> sudah disiapkan di repositori ini.
            </p>

            {/* Steps list */}
            <div className="space-y-2.5">
              <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="w-6 h-6 rounded-full bg-slate-800 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div className="flex-1">
                  <span className="font-semibold text-slate-900">Hubungkan ke GitHub Repository</span>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Buat repository baru di GitHub Anda (misal: <code>bendahara-sekolah</code>) lalu dorong kode ini:
                  </p>
                  <div className="mt-2 relative">
                    <pre className="bg-slate-900 text-slate-100 p-2.5 rounded-lg text-[11px] font-mono overflow-x-auto">
                      {gitCommands}
                    </pre>
                    <button
                      type="button"
                      onClick={handleCopyCommands}
                      className="absolute right-2 top-2 p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs flex items-center gap-1"
                    >
                      {copiedCommand ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="w-6 h-6 rounded-full bg-slate-800 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div className="flex-1">
                  <span className="font-semibold text-slate-900">Import Project di Dashboard Vercel</span>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Buka <a href="https://vercel.com/new" target="_blank" rel="noreferrer" className="text-emerald-700 underline font-semibold">vercel.com/new</a>, pilih repositori GitHub Anda, dan klik <strong>Deploy</strong>. Vercel secara otomatis mendeteksi konfigurasi <code>Vite</code> dan <code>vercel.json</code>.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="w-6 h-6 rounded-full bg-slate-800 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div className="flex-1">
                  <span className="font-semibold text-slate-900">Auto Update Aktif (Setiap Git Push)</span>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Setiap kali Anda melakukan update/edit data di GitHub, Vercel akan <strong>secara otomatis me-rebuild dan memperbarui web</strong> secara instan tanpa perlu upload manual.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-slate-50 rounded-xl border border-slate-200">
                <span className="w-6 h-6 rounded-full bg-slate-800 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  4
                </span>
                <div className="flex-1">
                  <span className="font-semibold text-slate-900">Kustom Domain Sekolah (Opsional)</span>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Anda dapat menghubungkan domain resmi sekolah gratis melalui menu <strong>Vercel Settings &gt; Domains</strong> (contoh: <code>bendahara.smpn1.sch.id</code>).
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Konfigurasi Vercel &amp; Serverless function sudah aktif.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl transition-colors"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
