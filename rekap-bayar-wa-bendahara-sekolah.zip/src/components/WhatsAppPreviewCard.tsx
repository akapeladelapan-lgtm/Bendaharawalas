import React, { useState, useMemo } from 'react';
import {
  Copy,
  Check,
  Share2,
  Download,
  Printer,
  Smartphone,
  Eye,
  Send,
  Layers,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';
import { StudentPayment, MessageConfig } from '../types/payment';
import { generateWhatsAppMessage, groupStudentsByClass } from '../utils/whatsappFormatter';

interface WhatsAppPreviewCardProps {
  students: StudentPayment[];
  config: MessageConfig;
  showToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export const WhatsAppPreviewCard: React.FC<WhatsAppPreviewCardProps> = ({
  students,
  config,
  showToast,
}) => {
  const [selectedClassTab, setSelectedClassTab] = useState<string>('all');
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'preview' | 'raw'>('preview');

  // Extract all unique classes in sorted order
  const classGroups = useMemo(() => groupStudentsByClass(students), [students]);
  const classNames = classGroups.map((g) => g.classGrade);

  // Generated WhatsApp plain text
  const messageText = useMemo(() => {
    return generateWhatsAppMessage(students, config, selectedClassTab);
  }, [students, config, selectedClassTab]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(messageText);
      setCopied(true);
      showToast('Pesan WhatsApp berhasil disalin ke clipboard!', 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      showToast('Gagal menyalin otomatis, silakan salin manual dari kotak teks.', 'error');
    }
  };

  const handleOpenWhatsApp = () => {
    const encoded = encodeURIComponent(messageText);
    const url = `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleDownloadTxt = () => {
    const element = document.createElement('a');
    const file = new Blob([messageText], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    const filename = `Rekap_Pembayaran_${selectedClassTab === 'all' ? 'Semua_Kelas' : selectedClassTab}_${new Date().toISOString().slice(0, 10)}.txt`;
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    showToast(`File ${filename} berhasil diunduh!`, 'success');
  };

  const handlePrint = () => {
    window.print();
  };

  // Convert WhatsApp markdown (*bold*, _italic_) into React elements for the live chat bubble preview
  const renderedFormattedText = useMemo(() => {
    const lines = messageText.split('\n');
    return lines.map((line, lineIdx) => {
      if (line === '') {
        return <div key={lineIdx} className="h-3" />;
      }

      if (line.startsWith('────────')) {
        return (
          <div key={lineIdx} className="my-1.5 border-t border-emerald-900/10 dark:border-white/10" />
        );
      }

      // Parse bold *text* and italic _text_
      const parts: React.ReactNode[] = [];
      const regex = /(\*[^*]+\*|_[^_]+_)/g;
      let lastIndex = 0;
      let match;

      while ((match = regex.exec(line)) !== null) {
        if (match.index > lastIndex) {
          parts.push(line.substring(lastIndex, match.index));
        }
        const token = match[0];
        if (token.startsWith('*') && token.endsWith('*')) {
          const content = token.slice(1, -1);
          // Highlight status headers distinctly
          const isLunas = content.includes('LUNAS');
          const isAngsuran1 = content.includes('ANGSURAN') || content.includes('CICILAN');
          const isClass = content.startsWith('KELAS');

          let badgeClass = 'font-bold text-slate-900';
          if (isLunas) badgeClass = 'font-bold text-emerald-800 bg-emerald-50 px-1 py-0.5 rounded';
          else if (isAngsuran1) badgeClass = 'font-bold text-orange-800 bg-orange-50 px-1 py-0.5 rounded';
          else if (isClass) badgeClass = 'font-extrabold text-teal-900 text-[13px] tracking-wide block mt-1';

          parts.push(
            <span key={`${lineIdx}-${match.index}`} className={badgeClass}>
              {content}
            </span>
          );
        } else if (token.startsWith('_') && token.endsWith('_')) {
          parts.push(
            <em key={`${lineIdx}-${match.index}`} className="italic text-slate-500">
              {token.slice(1, -1)}
            </em>
          );
        }
        lastIndex = regex.lastIndex;
      }

      if (lastIndex < line.length) {
        parts.push(line.substring(lastIndex));
      }

      return (
        <div key={lineIdx} className="leading-relaxed">
          {parts.length > 0 ? parts : line}
        </div>
      );
    });
  }, [messageText]);

  const activeClassLabel =
    selectedClassTab === 'all'
      ? 'Semua Kelas'
      : selectedClassTab.toUpperCase().startsWith('KELAS')
      ? selectedClassTab.toUpperCase()
      : `Kelas ${selectedClassTab.toUpperCase()}`;

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col h-full">
      {/* Top Bar */}
      <div className="px-5 py-3.5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-50/70">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
            <Smartphone className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-base font-semibold text-slate-900">
                Pesan WhatsApp Siap Salin
              </h2>
              <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                Format Terverifikasi
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Sesuai aturan 1-7 (pengelompokan kelas, bold status, salam & instruksi)
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-1.5 self-end sm:self-auto">
          <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-white">
            <button
              type="button"
              onClick={() => setViewMode('preview')}
              className={`px-2.5 py-1 text-xs rounded-md font-medium transition-all flex items-center gap-1 ${
                viewMode === 'preview'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Eye className="w-3.5 h-3.5" />
              Tampilan WA
            </button>
            <button
              type="button"
              onClick={() => setViewMode('raw')}
              className={`px-2.5 py-1 text-xs rounded-md font-medium transition-all flex items-center gap-1 ${
                viewMode === 'raw'
                  ? 'bg-emerald-600 text-white shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Teks Mentah
            </button>
          </div>
        </div>
      </div>

      {/* Class Group Tabs (Crucial for treasurers who post to individual class groups) */}
      <div className="px-5 py-2.5 bg-slate-100/70 border-b border-slate-200/80 flex items-center space-x-2 overflow-x-auto text-xs no-scrollbar">
        <span className="text-slate-500 font-medium shrink-0 flex items-center mr-1">
          <Layers className="w-3.5 h-3.5 mr-1" />
          Target Kirim:
        </span>
        <button
          type="button"
          onClick={() => setSelectedClassTab('all')}
          className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
            selectedClassTab === 'all'
              ? 'bg-emerald-600 text-white shadow-xs font-semibold'
              : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
          }`}
        >
          Semua Kelas ({students.length})
        </button>

        {classGroups.map((g) => (
          <button
            key={g.classGrade}
            type="button"
            onClick={() => setSelectedClassTab(g.classGrade)}
            className={`px-3 py-1.5 rounded-xl font-medium shrink-0 transition-all ${
              selectedClassTab === g.classGrade
                ? 'bg-emerald-600 text-white shadow-xs font-semibold'
                : 'bg-white text-slate-700 hover:bg-slate-200/80 border border-slate-200'
            }`}
          >
            {g.classGrade.toUpperCase().startsWith('KELAS')
              ? g.classGrade.toUpperCase()
              : `Kelas ${g.classGrade.toUpperCase()}`}{' '}
            <span className="text-[11px] opacity-80">({g.totalStudents})</span>
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="p-4 sm:p-5 flex-1 flex flex-col bg-slate-50/50">
        {viewMode === 'preview' ? (
          /* WhatsApp Phone Simulator Screen */
          <div className="w-full flex-1 rounded-2xl overflow-hidden border border-slate-300 shadow-inner flex flex-col bg-[#e5ddd5] dark:bg-slate-800">
            {/* WhatsApp App Header Mock */}
            <div className="bg-[#075E54] text-white px-3.5 py-2.5 flex items-center justify-between shadow-xs">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-200 text-emerald-900 font-bold flex items-center justify-center text-xs shadow-2xs">
                  🏫
                </div>
                <div>
                  <div className="text-xs sm:text-sm font-semibold leading-tight">
                    {config.schoolName || 'Grup Paguyuban / Komite'} - {activeClassLabel}
                  </div>
                  <div className="text-[10px] text-emerald-200 leading-none mt-0.5">
                    Online • Rekap Pembayaran Resmi
                  </div>
                </div>
              </div>
              <div className="text-[11px] text-emerald-200 bg-emerald-900/50 px-2 py-0.5 rounded">
                WhatsApp Preview
              </div>
            </div>

            {/* Chat Body Wallpaper Background */}
            <div className="flex-1 p-3.5 sm:p-5 overflow-y-auto max-h-[500px] min-h-[340px] space-y-3 bg-[radial-gradient(#00000008_1px,transparent_1px)] [background-size:16px_16px]">
              {/* Date Pill */}
              <div className="flex justify-center">
                <span className="bg-white/80 dark:bg-slate-700/80 shadow-2xs text-[11px] text-slate-600 dark:text-slate-200 px-3 py-1 rounded-full font-medium">
                  {config.updateDate || 'Hari ini'}
                </span>
              </div>

              {/* Speech Bubble */}
              <div className="flex justify-start">
                <div className="max-w-[92%] sm:max-w-[85%] bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 rounded-2xl rounded-tl-xs p-4 shadow-sm border border-black/5 text-xs sm:text-[13px] font-sans whitespace-pre-wrap select-text relative">
                  {renderedFormattedText}

                  {/* Timestamp & Double Checkmark */}
                  <div className="flex items-center justify-end space-x-1 text-[10px] text-slate-400 mt-2">
                    <span>
                      {new Date().toLocaleTimeString('id-ID', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                    <span className="text-blue-500 font-bold">✓✓</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Raw Text Area (for quick manual selection if needed) */
          <div className="flex-1 flex flex-col">
            <textarea
              readOnly
              value={messageText}
              rows={18}
              className="w-full flex-1 font-mono text-xs sm:text-sm bg-white border border-slate-300 rounded-xl p-4 text-slate-800 focus:outline-none select-all"
            />
          </div>
        )}

        {/* Footer Meta */}
        <div className="flex items-center justify-between text-xs text-slate-500 mt-3 px-1">
          <div className="flex items-center gap-2">
            <span>
              Target: <strong className="text-slate-700">{activeClassLabel}</strong>
            </span>
            <span>•</span>
            <span>{messageText.length} karakter</span>
            <span>•</span>
            <span>{messageText.split('\n').length} baris</span>
          </div>

          <div className="text-[11px] text-emerald-700 font-medium">
            ✅ Aturan *Bold* & Pemisah Ribuan Aktif
          </div>
        </div>

        {/* Action Buttons Toolbar */}
        <div className="mt-4 pt-3 border-t border-slate-200/80 flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={handleDownloadTxt}
              className="inline-flex items-center px-3 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-2xs transition-colors"
              title="Unduh format teks .txt"
            >
              <Download className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
              Unduh .txt
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="hidden sm:inline-flex items-center px-3 py-2 text-xs font-medium text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-2xs transition-colors"
              title="Cetak atau Simpan PDF"
            >
              <Printer className="w-3.5 h-3.5 mr-1.5 text-slate-500" />
              Cetak / PDF
            </button>
          </div>

          <div className="flex items-center space-x-2.5">
            <button
              type="button"
              onClick={handleOpenWhatsApp}
              className="inline-flex items-center px-3.5 py-2.5 text-xs sm:text-sm font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 rounded-xl transition-all shadow-xs active:scale-95"
              title="Kirim langsung lewat aplikasi WhatsApp atau WhatsApp Web"
            >
              <ExternalLink className="w-4 h-4 mr-1.5" />
              Kirim via WhatsApp
            </button>

            <button
              type="button"
              onClick={handleCopy}
              className={`inline-flex items-center px-5 py-2.5 text-xs sm:text-sm font-bold text-white rounded-xl shadow-sm transition-all active:scale-95 ${
                copied
                  ? 'bg-emerald-700 ring-2 ring-emerald-400'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-1.5" />
                  Berhasil Disalin!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-1.5" />
                  Salin Pesan WhatsApp
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
