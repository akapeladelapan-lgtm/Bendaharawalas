import React from 'react';
import {
  Settings2,
  MessageCircle,
  AlertCircle,
  Calendar,
  User,
  School,
  Tag,
  Coins,
  Layers,
} from 'lucide-react';
import { MessageConfig } from '../types/payment';
import { parseNominal, formatRupiah } from '../utils/numberFormat';

interface ConfigPanelProps {
  config: MessageConfig;
  onChangeConfig: (newConfig: MessageConfig) => void;
  onResetDefault: () => void;
}

export const ConfigPanel: React.FC<ConfigPanelProps> = ({
  config,
  onChangeConfig,
  onResetDefault,
}) => {
  const updateField = <K extends keyof MessageConfig>(key: K, value: MessageConfig[K]) => {
    onChangeConfig({
      ...config,
      [key]: value,
    });
  };

  const updateTariff = (key: 'angsuranPertama' | 'lunas', val: string) => {
    const num = parseNominal(val);
    onChangeConfig({
      ...config,
      paymentTariffs: {
        ...config.paymentTariffs,
        [key]: num,
      },
    });
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
        <div className="flex items-center space-x-2.5">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Settings2 className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-semibold text-slate-900">
              Pengaturan Teks & Skema Pembayaran
            </h2>
            <p className="text-xs text-slate-500">
              Sesuaikan besaran tarif (1.700.000 / 3.350.000), salam, dan instruksi WA
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onResetDefault}
          className="text-xs text-slate-500 hover:text-slate-800 underline transition-colors"
        >
          Reset Format Standar
        </button>
      </div>

      <div className="p-5 space-y-4">
        {/* SKEMA TARIF PEMBAYARAN */}
        <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5 uppercase tracking-wide">
              <Coins className="w-4 h-4 text-emerald-700" />
              Skema Tarif Pembayaran Siswa
            </span>
            <label className="inline-flex items-center cursor-pointer text-xs font-medium text-emerald-900 select-none">
              <input
                type="checkbox"
                checked={config.includeTariffSchemeInMessage}
                onChange={(e) => updateField('includeTariffSchemeInMessage', e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded border-emerald-300 focus:ring-emerald-500"
              />
              <span className="ml-1.5">Tampilkan rincian ini di pesan WhatsApp</span>
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                1. Angsuran Pertama (Rp)
              </label>
              <input
                type="text"
                value={formatRupiah(config.paymentTariffs.angsuranPertama, false)}
                onChange={(e) => updateTariff('angsuranPertama', e.target.value)}
                className="w-full text-xs font-mono font-bold bg-white border border-emerald-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-700 block mb-1">
                2. Lunas Total (Rp)
              </label>
              <input
                type="text"
                value={formatRupiah(config.paymentTariffs.lunas, false)}
                onChange={(e) => updateTariff('lunas', e.target.value)}
                className="w-full text-xs font-mono font-bold bg-white border border-emerald-300 rounded-lg px-2.5 py-1.5 text-slate-800 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Row 1: Judul Kegiatan & Sekolah */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label className="text-xs font-semibold text-slate-700 flex items-center mb-1">
              <Tag className="w-3.5 h-3.5 mr-1 text-slate-400" />
              Nama Kegiatan / Iuran
            </label>
            <input
              type="text"
              value={config.activityTitle}
              onChange={(e) => updateField('activityTitle', e.target.value)}
              placeholder="Contoh: Rekap Pembayaran Biaya Masuk & Seragam"
              className="w-full text-xs sm:text-sm bg-slate-50/70 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 flex items-center mb-1">
              <School className="w-3.5 h-3.5 mr-1 text-slate-400" />
              Nama Sekolah / Lembaga
            </label>
            <input
              type="text"
              value={config.schoolName}
              onChange={(e) => updateField('schoolName', e.target.value)}
              placeholder="Contoh: SMP Negeri 1 Nusantara"
              className="w-full text-xs sm:text-sm bg-slate-50/70 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Row 2: Tanggal & Nama Bendahara */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          <div>
            <label className="text-xs font-semibold text-slate-700 flex items-center mb-1">
              <Calendar className="w-3.5 h-3.5 mr-1 text-slate-400" />
              Tanggal Pembaruan
            </label>
            <input
              type="text"
              value={config.updateDate}
              onChange={(e) => updateField('updateDate', e.target.value)}
              placeholder="Contoh: Minggu, 18 Oktober 2026"
              className="w-full text-xs sm:text-sm bg-slate-50/70 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 flex items-center mb-1">
              <User className="w-3.5 h-3.5 mr-1 text-slate-400" />
              Nama & Kontak Bendahara
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={config.treasurerName}
                onChange={(e) => updateField('treasurerName', e.target.value)}
                placeholder="Nama Bendahara"
                className="flex-1 text-xs sm:text-sm bg-slate-50/70 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
              <input
                type="text"
                value={config.treasurerContact || ''}
                onChange={(e) => updateField('treasurerContact', e.target.value)}
                placeholder="No. WA (opsional)"
                className="w-36 text-xs sm:text-sm bg-slate-50/70 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Salam Pembuka */}
        <div>
          <label className="text-xs font-semibold text-slate-700 flex items-center mb-1">
            <MessageCircle className="w-3.5 h-3.5 mr-1 text-emerald-600" />
            Salam Pembuka Sopan
          </label>
          <textarea
            value={config.headerGreeting}
            onChange={(e) => updateField('headerGreeting', e.target.value)}
            rows={2}
            className="w-full text-xs sm:text-sm bg-slate-50/70 border border-slate-200 rounded-xl p-3 text-slate-800 focus:bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        {/* Instruksi Belum Tercatat / Rekening Pribadi Bendahara */}
        <div>
          <label className="text-xs font-semibold text-slate-700 flex items-center mb-1 text-amber-800">
            <AlertCircle className="w-3.5 h-3.5 mr-1 text-amber-600" />
            Instruksi Transfer Belum Tercatat / Rekening Pribadi Bendahara
          </label>
          <textarea
            value={config.closingInstruction}
            onChange={(e) => updateField('closingInstruction', e.target.value)}
            rows={3}
            className="w-full text-xs sm:text-sm bg-amber-50/40 border border-amber-200 rounded-xl p-3 text-slate-800 focus:bg-white focus:ring-1 focus:ring-amber-500 focus:outline-none"
          />
        </div>

        {/* Switch Options: Nominal & Numbering */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs">
          <label className="inline-flex items-center cursor-pointer select-none">
            <input
              type="checkbox"
              checked={config.showAmount}
              onChange={(e) => updateField('showAmount', e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
            />
            <span className="ml-2 font-medium text-slate-700">
              Sertakan Nominal Pembayaran (Rp) pada setiap nama siswa
            </span>
          </label>

          <div className="flex items-center space-x-2">
            <span className="font-medium text-slate-700">Gaya Penomoran:</span>
            <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-50">
              <button
                type="button"
                onClick={() => updateField('numberingStyle', 'numeric')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-all ${
                  config.numberingStyle === 'numeric'
                    ? 'bg-white text-emerald-700 shadow-2xs font-semibold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                1. 2. 3. (Angka)
              </button>
              <button
                type="button"
                onClick={() => updateField('numberingStyle', 'bullet')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-all ${
                  config.numberingStyle === 'bullet'
                    ? 'bg-white text-emerald-700 shadow-2xs font-semibold'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                • (Bullet)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
