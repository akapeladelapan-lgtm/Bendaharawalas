import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '10mb' }));

// Initialize GoogleGenAI client (Server-side only)
const ai = process.env.GEMINI_API_KEY
  ? new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// API endpoint: AI Smart Parser for messy school payment records
app.post('/api/parse-payments', async (req, res) => {
  try {
    const { rawText } = req.body;
    if (!rawText || typeof rawText !== 'string' || !rawText.trim()) {
      return res.status(400).json({ error: 'Data mentah teks wajib diisi.' });
    }

    if (!ai) {
      return res.status(503).json({
        error: 'Layanan AI belum siap (GEMINI_API_KEY tidak ditemukan). Silakan gunakan parser manual.',
      });
    }

    const prompt = `Anda adalah asisten khusus bendahara sekolah di Indonesia.
Analisis teks mentah pembayaran siswa berikut dan ekstrak daftar siswa dengan teliti.

Skema Tarif Pembayaran Sekolah:
1. Angsuran Pertama: Rp 1.700.000
2. Lunas: Rp 3.350.000

Teks Mentah:
"""
${rawText}
"""

Aturan Ekstraksi:
1. Nama: Nama lengkap atau nama panggilan siswa yang jelas.
2. Kelas: Standarkan format kelas (contoh: "7A", "7B", "8A", "Kelas 1", "X IPA 1"). Jika kelas tidak disebutkan, gunakan "7A".
3. Status Pembayaran: HARUS salah satu dari dua nilai ini:
   - "LUNAS" (jika lunas, bayar full, lns, Rp 3.350.000, atau sudah lunas)
   - "ANGSURAN PERTAMA" (jika baru bayar tahap 1, cicilan, angsuran 1, dp, Rp 1.700.000)
4. Nominal: Angka murni integer (misal 1700000 atau 3350000). Jika tidak tercantum di teks, isi dengan nominal tarif default sesuai statusnya (Angsuran 1: 1700000, Lunas: 3350000).
5. Catatan: Informasi tambahan jika ada (misal tanggal transfer, metode, atau keterangan khusus).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'Anda adalah sistem ekstraksi data pembayaran sekolah yang akurat dan konsisten.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          description: 'Daftar data pembayaran siswa hasil ekstraksi',
          items: {
            type: Type.OBJECT,
            properties: {
              name: {
                type: Type.STRING,
                description: 'Nama siswa',
              },
              classGrade: {
                type: Type.STRING,
                description: 'Kelas siswa (misal 7A, 7B, 1A, dsb)',
              },
              status: {
                type: Type.STRING,
                description: 'Status pembayaran ("LUNAS" atau "ANGSURAN PERTAMA")',
              },
              amount: {
                type: Type.NUMBER,
                description: 'Nominal pembayaran integer (misal 1700000 atau 3350000)',
              },
              notes: {
                type: Type.STRING,
                description: 'Keterangan tambahan opsional',
              },
            },
            required: ['name', 'classGrade', 'status'],
          },
        },
      },
    });

    const parsedData = JSON.parse(response.text || '[]');
    return res.json({ success: true, students: parsedData });
  } catch (error: any) {
    console.error('Error parsing payments with Gemini:', error);
    return res.status(500).json({
      error: error?.message || 'Gagal memproses data dengan AI',
    });
  }
});

// Setup Vite in Dev or serve static in Prod
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server Bendahara Sekolah running at http://0.0.0.0:${port}`);
  });
}

startServer();
