import { GoogleGenAI, Type } from '@google/genai';

export default async function handler(req: any, res: any) {
  // Allow CORS if needed
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const { rawText } = req.body || {};
    if (!rawText || typeof rawText !== 'string' || !rawText.trim()) {
      return res.status(400).json({ error: 'Data mentah teks wajib diisi.' });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: 'GEMINI_API_KEY belum dikonfigurasi di Vercel Environment Variables. Gunakan ekstraksi lokal.',
      });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const prompt = `Anda adalah asisten khusus bendahara sekolah di Indonesia.
Analisis teks mentah pembayaran siswa berikut dan ekstrak daftar siswa dengan teliti.

Skema Tarif Pembayaran Sekolah:
1. Angsuran Pertama: Rp 1.700.000
2. Lunas: Rp 3.350.000

Teks Mentah:
"""
${rawText}
"""

Aturan Ekstraksi:
1. Nama: Nama lengkap atau nama panggilan siswa yang jelas.
2. Kelas: Standarkan format kelas (contoh: "7A", "7B", "8A", "Kelas 1", "X IPA 1"). Jika kelas tidak disebutkan, gunakan "7A".
3. Status Pembayaran: HARUS salah satu dari dua nilai ini:
   - "LUNAS" (jika lunas, bayar full, lns, Rp 3.350.000, atau sudah lunas)
   - "ANGSURAN PERTAMA" (jika baru bayar tahap 1, cicilan, angsuran 1, dp, Rp 1.700.000)
4. Nominal: Angka murni integer (misal 1700000 atau 3350000). Jika tidak tercantum di teks, isi dengan nominal tarif default sesuai statusnya (Angsuran 1: 1700000, Lunas: 3350000).
5. Catatan: Informasi tambahan jika ada (misal tanggal transfer, metode, atau keterangan khusus).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'Anda adalah sistem ekstraksi data pembayaran sekolah yang akurat dan konsisten.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          description: 'Daftar data pembayaran siswa hasil ekstraksi',
          items: {
            type: Type.OBJECT,
            properties: {
              name: {
                type: Type.STRING,
                description: 'Nama siswa',
              },
              classGrade: {
                type: Type.STRING,
                description: 'Kelas siswa (misal 7A, 7B, 1A, dsb)',
              },
              status: {
                type: Type.STRING,
                description: 'Status pembayaran ("LUNAS" atau "ANGSURAN PERTAMA")',
              },
              amount: {
                type: Type.NUMBER,
                description: 'Nominal pembayaran integer (misal 1700000 atau 3350000)',
              },
              notes: {
                type: Type.STRING,
                description: 'Keterangan tambahan opsional',
              },
            },
            required: ['name', 'classGrade', 'status'],
          },
        },
      },
    });

    const parsedData = JSON.parse(response.text || '[]');
    return res.status(200).json({ success: true, students: parsedData });
  } catch (error: any) {
    console.error('Error parsing payments on Vercel Function:', error);
    return res.status(500).json({
      error: error?.message || 'Gagal memproses data dengan AI',
    });
  }
}
